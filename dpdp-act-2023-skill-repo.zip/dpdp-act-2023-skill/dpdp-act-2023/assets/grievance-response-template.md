# Grievance / Rights Request Response (ss. 11–14, 13)

Subject: Your privacy request [Ref #] — [Access / Correction / Erasure / Grievance / Nomination]

Dear [Name],
Thank you for your request dated [date]. We verified your identity via [method].

**Outcome:** [Completed / Partially completed / Not able to action]
- [Access] Summary of your data and processing: [attach summary]; organisations we shared it with: [list of Fiduciaries/Processors + data shared] (s. 11(1))
- [Correction] We corrected/completed/updated: [fields] (s. 12(2))
- [Erasure] We erased: [data]. We have retained [data] because [specified purpose still being served / legal requirement: cite law] (s. 12(3)); it will be deleted by [date]. We have also instructed our processors to erase your data.
- [Nomination] We recorded [nominee] (s. 14)

If you are not satisfied, reply to this message or contact our [DPO/Grievance Officer, contact].
Having used our grievance process, you may also complain to the Data Protection Board of India (s. 13(3)).

[Name, role], [Company] · Response date: [date] (within [≤ 90] days of receipt)
