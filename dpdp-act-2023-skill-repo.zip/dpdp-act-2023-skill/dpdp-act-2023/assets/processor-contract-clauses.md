# Data Processor Contract Clauses — "Valid Contract" (s. 8(2))
<!-- Fiduciary remains liable (s. 8(1)); these clauses let it discharge ss. 6(6), 8(5),
     8(6), 8(7)(b), 11(1)(b), 16. Adapt; have counsel review. -->

1. **Instructions & purpose.** Processor processes Personal Data only on documented instructions of the Fiduciary and only for [services]; no processing for its own purposes (including model training).
2. **Security.** Processor implements safeguards at least equivalent to Annex [Security] (encryption, access control, logging ≥ 1 year, backups, vulnerability management) consistent with s. 8(5) and Rule 6.
3. **Confidentiality.** Personnel bound by confidentiality; access on need-to-know.
4. **Sub-processors.** Prior written authorisation; flow-down of equal obligations; current list at [link]; [30] days' notice of changes with right to object.
5. **Breach notice.** Notify Fiduciary without undue delay and in any event within [6–24] hours of becoming aware, with the information the Fiduciary needs for Rule 7 and CERT-In reporting; cooperate in investigation and notices.
6. **Cease & erase.** On instruction (consent withdrawal, end of purpose, erasure request) cease processing within [x] days and erase, including from sub-processors and backups (or crypto-shred), and certify in writing.
7. **Assistance with rights.** Provide data, correction, erasure and sharing information within [x] days to enable ss. 11–14 responses.
8. **Location & transfer.** Store/process only in [India / approved regions]; no transfer to countries notified under s. 16 or restricted by sectoral law; disclose support access locations.
9. **Accuracy.** Do not alter data except as instructed; propagate corrections.
10. **Audit.** Provide information, certifications (ISO 27001/27701, SOC 2) and permit audits/inspections; support SDF data audits (s. 10(2)(b)).
11. **Records.** Maintain processing logs for ≥ 1 year and provide on request.
12. **Return/deletion on exit.** Return or delete all Personal Data at termination; certificate of deletion.
13. **Children.** No tracking, behavioural monitoring or targeted advertising involving children's data (s. 9(3)).
14. **Liability & indemnity.** Allocation for penalties/costs caused by Processor breach [negotiate].
15. **Government requests.** Notify Fiduciary of legal requests unless legally prohibited.
