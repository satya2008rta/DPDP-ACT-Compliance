# ADR-[n]: [Decision title]
Status: [Proposed/Accepted] · Date: [ ] · Owners: [ ]

## Context
[Problem, workload, constraints]

## Decision
[Chosen option]

## DPDP considerations
| Question | Answer |
|---|---|
| Personal data held (items, children?) | |
| Purposes & lawful basis (consent / s.7 clause) | |
| How consent withdrawal reaches this component (s.6(6)) | |
| How one subject's data is erased; lag; evidence (s.8(7), 12(3)) | |
| Backups / time-travel / replicas handling | |
| Security controls (Rule 6) & logging ≥ 1 yr | |
| Breach: can we enumerate affected subjects + contacts? (s.8(6)) | |
| Location of storage, processing, support access (s.16, sectoral) | |
| Processors involved; contract in place (s.8(2)) | |
| Accuracy if used for decisions (s.8(3)) | |

## Alternatives considered
[Options and why rejected]

## Consequences
[Trade-offs, follow-ups]
