# Privacy Notice — [Product / Service Name]
<!-- DPDP Act s. 5(1) + Rule 3. Standalone, plain language, itemised.
     Offer in English + any Eighth Schedule language (s. 5(3)). -->

**Data Fiduciary:** [Legal entity name], [address]
**Notice version:** [vX.Y] · **Effective:** [date] · **Language:** [English ▾ / हिन्दी / ଓଡ଼ିଆ / …]

## 1. What personal data we collect and why
| Personal data (itemised) | Purpose (specified purpose) | Goods/service/use it enables | Basis |
|---|---|---|---|
| Name, mobile number | Create and secure your account | Login, OTP | Consent |
| Delivery address | Deliver your orders | Shipping | Consent |
| [Optional] Location | [Nearby store suggestions] | [Feature] | Consent (optional — you can say no) |
| [Data] | [Purpose] | [Use] | [Consent / s. 7(x) legitimate use] |

We only collect what is necessary for these purposes. Optional items are asked separately.

## 2. Your consent and how to withdraw it
You can withdraw consent for any purpose at any time at **[Settings → Privacy]** or
[link] — as easily as you gave it. Withdrawal does not affect processing already
done. If you withdraw, we [consequence, e.g. cannot deliver new orders], but will
complete orders already paid for.

## 3. Your rights
- Get a summary of your personal data and who we shared it with (s. 11)
- Correct, complete, update or erase your data (s. 12)
- Nominate someone to exercise your rights on death/incapacity (s. 14)
- Raise a grievance — we respond within [≤ 90] days (s. 13)
Exercise rights at: [link / email / in-app]

## 4. Contact
[Data Protection Officer / Grievance Officer], [email], [phone], [address] (s. 8(9))

## 5. Complaint to the Data Protection Board of India
If you are not satisfied with our response to your grievance, you may complain to the
Data Protection Board of India at [Board's official portal/URL — verify].

<!-- Optional (not mandatory under s. 5 but good practice): processors / categories of
recipients, retention periods, cross-border transfers, children's data handling. -->
