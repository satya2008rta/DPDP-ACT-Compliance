# Data Protection Impact Assessment (s. 10(2)(c)(i), Rule 13)
<!-- Mandatory & periodic (annual under Rules) for SDFs; recommended for high-risk processing. -->

1. **Processing described** — system, purpose(s), data categories, volume, Data Principals (incl. children?), sources, recipients/processors, locations, retention.
2. **Rights of Data Principals & purposes** — lawful basis per purpose; how notice, consent, withdrawal, access, correction, erasure, grievance, nomination are delivered.
3. **Necessity & proportionality** — why each data item is necessary; alternatives considered (aggregation, anonymisation).
4. **Risk assessment** — for each risk: likelihood × severity to Data Principals (unauthorised access, excessive collection, inaccuracy leading to harmful decisions, function creep, re-identification, algorithmic bias, cross-border exposure, child detriment).
5. **Measures** — technical & organisational controls, residual risk, owner, due date.
6. **Algorithmic due diligence** (if AI/automated) — model purpose, data, testing for accuracy/bias, human oversight, monitoring.
7. **Sign-off** — DPO, business owner, CISO; date; next review.
