# Personal Data Breach — Intimation Templates (s. 8(6), Rule 7)
<!-- No harm threshold: every personal data breach is intimated to the Board AND each
     affected Data Principal. Stage 1 without delay; Stage 2 detailed report ≤ 72 hours
     (extendable by Board on request). Check current Board portal/format. Also assess
     CERT-In reporting (6 hours) separately. -->

## A. Stage 1 — Notice to each affected Data Principal (without delay)
Channel: [email / SMS / in-app / registered contact] · Language: [user's language]

Subject: Important: security incident affecting your [Company] account

Dear [Name],
On [date], we became aware of a security incident at [Company].
- **What happened:** [nature of breach, plain language]
- **When / where:** [timing; system/location]
- **Your data involved:** [items, e.g., name, email, order history]
- **What it could mean for you:** [likely consequences, e.g., phishing risk]
- **What we have done:** [containment and mitigation]
- **What you can do:** [reset password, beware of calls asking for OTP, monitor accounts]
- **Contact:** [DPO/contact, email, phone, reference no.]
We are sorry for this. We have informed the Data Protection Board of India.

## B. Stage 1 — Initial intimation to the Board (without delay)
- Data Fiduciary: [name, address, contact, DPO]
- Description of breach: nature, extent, timing, location
- Likely impact on Data Principals
- Approximate number of affected Data Principals / records; categories of data
- Initial containment steps

## C. Stage 2 — Detailed report to the Board (≤ 72 hours of becoming aware)
1. Updated and detailed description of the breach
2. Broad facts, circumstances and reasons/causes (root cause)
3. Measures implemented or proposed to mitigate risk
4. Findings on the person(s) who caused the breach (if known)
5. Remedial measures to prevent recurrence
6. Report on intimations given to affected Data Principals (count, channel, date)
7. Extension request (if needed) with reasons

## D. Internal evidence log (supports s. 33(2)(e) mitigation credit)
| Timestamp | Event | Owner | Evidence link |
|---|---|---|---|
| T0 | Detected | | |
| | Contained | | |
| | CERT-In reported (if applicable) | | |
| | DP notices sent (n=) | | |
| | Board Stage 1 | | |
| | Board Stage 2 | | |
