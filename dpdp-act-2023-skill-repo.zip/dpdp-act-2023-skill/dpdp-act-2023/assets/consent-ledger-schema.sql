-- DPDP-oriented reference schema (PostgreSQL 14+).
-- Goals: proof of consent (s.6(10)), withdrawal (s.6(4)-(6)), lawful-basis tracking (s.4,7),
-- retention/inactivity (s.8(7)-(8),(11)), children (s.9), nomination (s.14), processor acks.
-- Direct identifiers live only in `subject`, encrypted at app layer with a per-subject DEK
-- (crypto-shredding). Everything else references subject_id.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE subject (
  subject_id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  enc_name                bytea,            -- encrypted with subject DEK
  enc_email               bytea,
  enc_phone               bytea,
  dek_key_ref             text NOT NULL,    -- KMS reference to wrapped DEK; destroy to crypto-shred
  preferred_language      text DEFAULT 'en',-- English or Eighth Schedule language code
  is_child                boolean NOT NULL DEFAULT false,
  parent_subject_id       uuid REFERENCES subject(subject_id),
  parental_verification_ref text,           -- Rule 10 evidence (token ref, not raw ID)
  nominee_subject_id      uuid REFERENCES subject(subject_id),
  last_initiated_contact_at timestamptz,    -- s.8(11): only DP-initiated contact
  legal_hold_until        date,
  legal_hold_basis        text,
  status                  text NOT NULL DEFAULT 'active' CHECK (status IN ('active','pending_erasure','erased')),
  created_at              timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE purpose (
  purpose_id        text PRIMARY KEY,             -- e.g. 'order_fulfilment'
  description       text NOT NULL,
  lawful_basis      text NOT NULL CHECK (lawful_basis IN
                      ('consent','s7a','s7b','s7c','s7d','s7e','s7f','s7g','s7h','s7i')),
  data_items        text[] NOT NULL,              -- itemised (Rule 3)
  retention_iso     text,                         -- e.g. 'P3Y'
  allowed_for_children boolean NOT NULL DEFAULT false
);

CREATE TABLE notice_version (
  notice_id     text,
  version       text,
  language      text,
  content_hash  text NOT NULL,                    -- hash of rendered notice
  published_at  timestamptz NOT NULL,
  PRIMARY KEY (notice_id, version, language)
);

-- Append-only consent ledger (no UPDATE/DELETE granted to app role)
CREATE TABLE consent_event (
  event_id        bigserial PRIMARY KEY,
  subject_id      uuid NOT NULL REFERENCES subject(subject_id),
  purpose_id      text NOT NULL REFERENCES purpose(purpose_id),
  action          text NOT NULL CHECK (action IN ('granted','withdrawn','expired','legacy_notice_sent')),
  notice_id       text, notice_version text, notice_language text,
  method          text NOT NULL,   -- 'ui_click','otp','consent_manager','parent','api'
  actor           text NOT NULL,   -- 'self','parent','guardian','nominee','consent_manager:<id>'
  channel         text,            -- web/app/ivr/branch
  device_ref      text,            -- hashed device/IP
  occurred_at     timestamptz NOT NULL DEFAULT now(),
  prev_hash       text,
  row_hash        text NOT NULL    -- hash(prev_hash || row) -> tamper evidence
);
CREATE INDEX ON consent_event (subject_id, purpose_id, occurred_at DESC);

-- Current state view for fast PDP lookups
CREATE VIEW consent_current AS
SELECT DISTINCT ON (subject_id, purpose_id) subject_id, purpose_id, action, occurred_at
FROM consent_event
WHERE action IN ('granted','withdrawn','expired')
ORDER BY subject_id, purpose_id, occurred_at DESC;

-- Processors & propagation evidence (s.6(6), 8(7)(b), 11(1)(b))
CREATE TABLE processor (
  processor_id  text PRIMARY KEY,
  name          text NOT NULL,
  contract_ref  text NOT NULL,
  regions       text[] NOT NULL,
  deletion_api  text
);
CREATE TABLE purpose_processor (
  purpose_id   text REFERENCES purpose(purpose_id),
  processor_id text REFERENCES processor(processor_id),
  PRIMARY KEY (purpose_id, processor_id)
);
CREATE TABLE privacy_task (
  task_id       bigserial PRIMARY KEY,
  subject_id    uuid NOT NULL REFERENCES subject(subject_id),
  kind          text NOT NULL CHECK (kind IN ('withdrawal','erasure','correction','access','retention_expiry','pre_erasure_notice')),
  target        text NOT NULL,            -- internal system or processor_id
  status        text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','done','failed','escalated','held')),
  evidence      jsonb,
  due_at        timestamptz,
  completed_at  timestamptz
);

-- Rights requests & grievances (s.11-14, 13; <=90 days)
CREATE TABLE rights_request (
  request_id     bigserial PRIMARY KEY,
  subject_id     uuid REFERENCES subject(subject_id),
  type           text NOT NULL CHECK (type IN ('access','correction','completion','update','erasure','nomination','grievance')),
  received_at    timestamptz NOT NULL DEFAULT now(),
  due_at         timestamptz NOT NULL DEFAULT now() + interval '90 days',
  identity_verified boolean NOT NULL DEFAULT false,
  outcome        text,
  responded_at   timestamptz
);

-- Enforce append-only on ledger (example)
-- REVOKE UPDATE, DELETE ON consent_event FROM app_role;
