# Consent Request — UI Copy & Checklist (s. 6)

## Screen copy (example)
> **Your choices** · [English ▾]
> We'd like your permission to use your data as follows. Read our [notice](link).
>
> ☐ **Order updates on WhatsApp** — uses your mobile number to send delivery updates.
> ☐ **Personalised offers** — uses your purchase history to suggest products.
> ☐ **Share with [Partner] for [purpose]** — shares name and email.
>
> You can change these anytime in Settings → Privacy.
> Questions? Contact [DPO/authorised person, email] (s. 6(3)).
>
> [ Save choices ]   [ Continue without optional choices ]

## Checklist
- [ ] Notice shown before or with the request (s. 5(1))
- [ ] One toggle per purpose; nothing pre-ticked; no consent bundled into T&Cs
- [ ] Only data necessary for each purpose (s. 6(1)); OS permissions requested only when needed
- [ ] No clause waiving rights (e.g., right to complain) — invalid (s. 6(2))
- [ ] Plain language; English + Eighth Schedule language option (s. 6(3))
- [ ] DPO / contact person shown (s. 6(3))
- [ ] Withdrawal in the same place, same effort (s. 6(4))
- [ ] Ledger record: subject, purpose, notice version, method, language, channel, timestamp, device (s. 6(10))
- [ ] Child? → route to verifiable parental consent (s. 9(1)) and suppress tracking/ads
- [ ] Consent Manager integration path (s. 6(7)) once applicable
