# DPDP Gap Assessment — [Organisation] — [Date]
Scope: [entities, products, systems] · Role(s): [Fiduciary / Processor / SDF / Consent Manager]
Applicability: [s. 3 analysis; any s. 17 exemptions]

| # | Obligation | Section / Rule | Requirement | Current state | Gap | Risk (Sch. max) | Priority | Owner | Target |
|---|---|---|---|---|---|---|---|---|---|
| 1 | Lawful basis | s. 4, 7 | Each purpose mapped to consent or s. 7 clause | | | ₹50 cr | | | |
| 2 | Notice | s. 5, R3 | Itemised, standalone, multilingual | | | ₹50 cr | | | |
| 3 | Consent quality | s. 6(1)–(3) | Free, specific, necessary-only, plain language | | | ₹50 cr | | | |
| 4 | Withdrawal | s. 6(4)–(6) | Equal ease; processors cease | | | ₹50 cr | | | |
| 5 | Proof of consent | s. 6(10) | Consent ledger | | | ₹50 cr | | | |
| 6 | Processor contracts | s. 8(2) | Valid contract | | | ₹50 cr | | | |
| 7 | Accuracy | s. 8(3) | Complete, accurate, consistent | | | ₹50 cr | | | |
| 8 | Security safeguards | s. 8(5), R6 | Rule 6 minimums | | | ₹250 cr | | | |
| 9 | Breach intimation | s. 8(6), R7 | Board + each DP; 72h report | | | ₹200 cr | | | |
| 10 | Retention/erasure | s. 8(7)–(8), R8 | Schedule, engine, processors, backups | | | ₹50 cr | | | |
| 11 | Contact publication | s. 8(9), R9 | DPO/contact published | | | ₹50 cr | | | |
| 12 | Grievance | s. 8(10), 13 | Mechanism; ≤ 90 days | | | ₹50 cr | | | |
| 13 | Children | s. 9, R10–12 | VPC; no tracking/ads; no detriment | | | ₹200 cr | | | |
| 14 | SDF duties | s. 10, R13 | DPO, auditor, DPIA, audit, algo DD | | | ₹150 cr | | | |
| 15 | Access right | s. 11 | Summary + recipients | | | ₹50 cr | | | |
| 16 | Correction/erasure | s. 12 | Process + SLA | | | ₹50 cr | | | |
| 17 | Nomination | s. 14 | Process | | | ₹50 cr | | | |
| 18 | Cross-border | s. 16 | Transfer register; sectoral localisation | | | ₹50 cr | | | |
| 19 | Legacy consent notice | s. 5(2) | Notice to existing users | | | ₹50 cr | | | |
