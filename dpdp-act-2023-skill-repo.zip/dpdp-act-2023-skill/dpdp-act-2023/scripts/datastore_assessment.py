#!/usr/bin/env python3
"""Assess a JSON inventory of datastores against DPDP-driven storage criteria.

Usage:
  python datastore_assessment.py ../assets/datastore-inventory-example.json
  python datastore_assessment.py inventory.json --india-only -o report.md

Each datastore object may include (all optional; missing = flagged unknown):
  name, engine, holds_personal_data, holds_children_data, regions[], backup_regions[],
  encryption_at_rest, customer_managed_keys, field_level_encryption, access_logging,
  log_retention_days, retention_rule_defined, erasure_mechanism (hard_delete|anonymise|ttl|none),
  backup_retention_days, backup_erasure_strategy (crypto_shred|expire_and_reapply|none),
  time_travel_days, cdc_propagates_deletes, in_catalog, processor, processor_contract,
  non_prod_masked
"""
import argparse
import json
import sys

INDIA_PREFIXES = ("ap-south", "asia-south", "centralindia", "southindia", "westindia",
                  "india", "mumbai", "hyderabad", "pune", "chennai", "delhi", "in-")


def is_india(region):
    r = region.lower().replace(" ", "")
    return any(r.startswith(p) or p in r for p in INDIA_PREFIXES)


def check(ds, india_only):
    f = []  # (severity, section, message)
    g = ds.get
    if not g("holds_personal_data", True):
        return [("INFO", "-", "No personal data declared; verify with PII discovery.")]
    if not g("in_catalog"):
        f.append(("HIGH", "s. 8(4), 8(6), 11", "Not in data catalog/RoPA - breach impact and access requests cannot be answered."))
    if not g("encryption_at_rest"):
        f.append(("HIGH", "s. 8(5), Rule 6", "No encryption at rest."))
    if not g("customer_managed_keys"):
        f.append(("MEDIUM", "s. 8(5)", "No customer-managed keys - limits crypto-shredding and key control."))
    if not g("field_level_encryption"):
        f.append(("MEDIUM", "s. 8(5)", "No field-level encryption/tokenisation for direct identifiers."))
    if not g("access_logging"):
        f.append(("HIGH", "Rule 6", "No access logging on personal data."))
    lr = g("log_retention_days")
    if lr is None or lr < 365:
        f.append(("HIGH", "Rule 6/8", f"Log retention {lr} days < 365 required minimum."))
    if not g("retention_rule_defined"):
        f.append(("HIGH", "s. 8(7)-(8)", "No retention rule defined."))
    em = g("erasure_mechanism", "none")
    if em in (None, "none"):
        f.append(("HIGH", "s. 8(7), 12(3)", "No per-subject erasure mechanism."))
    bs = g("backup_erasure_strategy", "none")
    if bs in (None, "none"):
        f.append(("MEDIUM", "s. 8(7)", f"No backup erasure strategy (backup retention {g('backup_retention_days')} days). Use crypto-shred or expire+reapply."))
    tt = g("time_travel_days") or 0
    if tt > 7:
        f.append(("MEDIUM", "s. 8(7)", f"Time-travel/versioning keeps deleted data for {tt} days; reduce on PII tables."))
    if not g("cdc_propagates_deletes"):
        f.append(("MEDIUM", "s. 8(7)(b)", "Deletes not propagated downstream (CDC/ETL)."))
    if g("processor") and not g("processor_contract"):
        f.append(("HIGH", "s. 8(2)", f"Processor '{g('processor')}' without valid contract."))
    if not g("non_prod_masked"):
        f.append(("MEDIUM", "s. 8(5)", "Non-production copies not masked."))
    regions = (g("regions") or []) + (g("backup_regions") or [])
    foreign = [r for r in regions if not is_india(r)]
    if foreign:
        sev = "HIGH" if india_only else "INFO"
        f.append((sev, "s. 16", f"Data/backups outside India: {', '.join(foreign)}. Register transfer; check sectoral localisation."))
    if g("holds_children_data"):
        f.append(("INFO", "s. 9", "Children's data present - confirm no tracking/behavioural monitoring/targeted ads use; child flag enforced."))
    return f


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("inventory")
    p.add_argument("--india-only", action="store_true", help="Treat any non-India region as HIGH (sectoral/SDF localisation)")
    p.add_argument("-o", "--output")
    a = p.parse_args()
    with open(a.inventory, encoding="utf-8") as fh:
        inv = json.load(fh)
    lines = [f"# Datastore DPDP Assessment - {inv.get('organisation', '')}",
             "_Heuristic engineering check, not legal advice. Verify engine features for your version._\n"]
    totals = {"HIGH": 0, "MEDIUM": 0, "INFO": 0}
    for ds in inv.get("datastores", []):
        res = check(ds, a.india_only)
        lines.append(f"## {ds.get('name', '?')} ({ds.get('engine', '?')})")
        if not res:
            lines.append("No gaps found against the checked criteria.\n")
            continue
        lines.append("| Severity | Provision | Finding |\n|---|---|---|")
        for sev, sec, msg in sorted(res, key=lambda x: ["HIGH", "MEDIUM", "INFO"].index(x[0])):
            totals[sev] += 1
            lines.append(f"| {sev} | {sec} | {msg} |")
        lines.append("")
    lines.append(f"**Totals:** HIGH {totals['HIGH']}, MEDIUM {totals['MEDIUM']}, INFO {totals['INFO']}")
    text = "\n".join(lines) + "\n"
    if a.output:
        open(a.output, "w", encoding="utf-8").write(text)
        print(f"Wrote {a.output}")
    else:
        sys.stdout.write(text)


if __name__ == "__main__":
    main()
