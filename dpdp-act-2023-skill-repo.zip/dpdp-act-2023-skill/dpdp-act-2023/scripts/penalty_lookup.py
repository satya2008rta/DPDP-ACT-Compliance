#!/usr/bin/env python3
"""DPDP Act 2023 penalty Schedule (s. 33(1)) lookup.

Usage:
  python penalty_lookup.py all
  python penalty_lookup.py breach        # keyword search
  python penalty_lookup.py --factors     # s. 33(2) factors
"""
import argparse

SCHEDULE = [
    (1, "Failure to take reasonable security safeguards to prevent personal data breach", "s. 8(5)", "Up to Rs 250 crore", ["security", "safeguard", "breach", "encryption", "hack"]),
    (2, "Failure to give the Board or affected Data Principals notice of a personal data breach", "s. 8(6)", "Up to Rs 200 crore", ["breach", "notify", "notice", "intimation", "72"]),
    (3, "Breach of additional obligations in relation to children", "s. 9", "Up to Rs 200 crore", ["child", "children", "minor", "parent", "tracking", "ads"]),
    (4, "Breach of additional obligations of Significant Data Fiduciary", "s. 10", "Up to Rs 150 crore", ["sdf", "significant", "dpo", "dpia", "audit"]),
    (5, "Breach of duties of Data Principal", "s. 15", "Up to Rs 10,000", ["duty", "duties", "principal", "frivolous", "impersonate"]),
    (6, "Breach of any term of voluntary undertaking accepted by the Board", "s. 32", "Up to the extent applicable for the breach for which s. 28 proceedings were instituted", ["undertaking", "voluntary"]),
    (7, "Breach of any other provision of the Act or rules", "any other", "Up to Rs 50 crore", ["other", "consent", "notice", "erasure", "grievance", "retention", "contract", "processor", "rights", "transfer"]),
]
FACTORS = [
    "(a) nature, gravity and duration of the breach",
    "(b) type and nature of the personal data affected",
    "(c) repetitive nature of the breach",
    "(d) whether the person realised a gain or avoided a loss",
    "(e) mitigation action taken, and its timeliness and effectiveness",
    "(f) whether the penalty is proportionate and effective to deter",
    "(g) likely impact of the penalty on the person",
]
NOTES = [
    "Penalty only after inquiry finds breach 'significant' and hearing given (s. 33(1)).",
    "Amounts are maximums; Schedule can be amended up to 2x original (s. 42).",
    "Penalties go to Consolidated Fund of India (s. 34); no compensation to individuals.",
    "Two or more penalties on a Fiduciary can lead to a blocking reference (s. 37).",
    "1 crore = 10 million rupees.",
]


def show(rows):
    print("| # | Breach | Provision | Maximum |\n|---|---|---|---|")
    for n, d, s, m, _ in rows:
        print(f"| {n} | {d} | {s} | {m} |")


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("keyword", nargs="?", default="all")
    p.add_argument("--factors", action="store_true")
    a = p.parse_args()
    kw = a.keyword.lower()
    rows = SCHEDULE if kw == "all" else [r for r in SCHEDULE if kw in r[1].lower() or any(kw in t for t in r[4])]
    if not rows:
        print(f"No direct match for '{kw}'. Residual item 7 applies (up to Rs 50 crore).")
        rows = [SCHEDULE[6]]
    show(rows)
    if a.factors or kw == "all":
        print("\n**s. 33(2) factors:**")
        for f in FACTORS:
            print(f"- {f}")
    print("\n**Notes:**")
    for n in NOTES:
        print(f"- {n}")


if __name__ == "__main__":
    main()
