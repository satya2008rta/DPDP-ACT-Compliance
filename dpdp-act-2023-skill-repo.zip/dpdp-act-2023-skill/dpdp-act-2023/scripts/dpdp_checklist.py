#!/usr/bin/env python3
"""Generate a tailored DPDP Act 2023 obligations checklist (Markdown).

Examples:
  python dpdp_checklist.py                         # baseline Data Fiduciary
  python dpdp_checklist.py --web --processors
  python dpdp_checklist.py --children --processors --engineering
  python dpdp_checklist.py --sdf --cross-border --ai -o checklist.md
  python dpdp_checklist.py --role processor
"""
import argparse
import sys

BASE = [
    ("Applicability", "s. 3, 17", "Confirm digital/digitised data, India nexus, carve-outs and any s. 17 exemption; document the analysis."),
    ("Lawful basis", "s. 4, 7", "Map every purpose to consent or a specific s. 7 clause; no 'legitimate interests' catch-all."),
    ("Notice", "s. 5(1), 5(3), Rule 3", "Standalone, itemised notice (data, purpose, use), how to withdraw/exercise rights, how to complain to Board; English + Eighth Schedule languages."),
    ("Legacy notice", "s. 5(2)", "Send notice to Data Principals who consented before commencement."),
    ("Consent quality", "s. 6(1)-(3)", "Free, specific, informed, unconditional, unambiguous, affirmative; necessary data only; no rights waivers; DPO/contact shown."),
    ("Withdrawal", "s. 6(4)-(6)", "Withdrawal as easy as consent; stop processing and make Processors stop within reasonable time."),
    ("Proof of consent", "s. 6(10)", "Maintain auditable consent records tied to notice version."),
    ("Accountability", "s. 8(1), 8(4)", "Governance programme; technical & organisational measures; responsibility for Processors."),
    ("Accuracy", "s. 8(3)", "Ensure completeness/accuracy/consistency where data drives decisions or is shared with another Fiduciary."),
    ("Security safeguards", "s. 8(5), Rule 6", "Encryption/masking/tokenisation, access control, monitoring & logs >= 1 yr, backups, Processor contract safeguards. Max penalty Rs 250 cr."),
    ("Breach intimation", "s. 8(6), Rule 7", "Notify Board AND every affected Data Principal without delay; detailed Board report within 72h. No harm threshold. Max Rs 200 cr."),
    ("Retention & erasure", "s. 8(7)-(8), 8(11), Rule 8", "Erase on withdrawal or end of purpose (earlier of); inactivity periods; 48h pre-erasure notice where applicable; legal holds; Processors erase too."),
    ("Contact publication", "s. 8(9), Rule 9", "Publish DPO / authorised person business contact prominently on site/app and in responses."),
    ("Grievance mechanism", "s. 8(10), 13", "Effective grievance redressal; respond within prescribed period (<= 90 days)."),
    ("Right of access", "s. 11", "Provide summary of data & processing and list of Fiduciaries/Processors shared with (consent & s. 7(a) data)."),
    ("Correction & erasure", "s. 12", "Correct/complete/update; erase unless purpose or law requires retention."),
    ("Nomination", "s. 14", "Allow nomination for death/incapacity."),
    ("Cross-border", "s. 16", "Register transfers; check notified restricted countries and stricter sectoral laws."),
]
PROCESSORS = [
    ("Valid contract", "s. 8(2)", "Written contract with each Processor: instructions, security, breach notice SLA, cease/erase, assistance with rights, sub-processors, location, audit."),
    ("Processor propagation", "s. 6(6), 8(7)(b)", "Automated or SOP-based withdrawal/erasure instructions to Processors with acknowledgement evidence."),
    ("Sharing register", "s. 11(1)(b)", "Record which Fiduciaries/Processors received which data, per Data Principal where feasible."),
]
CHILDREN = [
    ("Age assurance", "s. 2(f), 9(1)", "Identify under-18 users (and persons with disability with lawful guardian)."),
    ("Verifiable parental consent", "s. 9(1), Rule 10-11", "Verify parent/guardian is an identifiable adult (e.g., existing verified account, authorised token)."),
    ("No detrimental processing", "s. 9(2)", "Assess and prevent processing likely to harm a child's well-being (cannot be exempted)."),
    ("No tracking/targeting", "s. 9(3)", "Disable tracking, behavioural monitoring and targeted advertising for children at platform level."),
    ("Exemptions scoped", "s. 9(4)-(5), Rule 12", "If relying on Fourth Schedule exemption, document class/purpose and limit processing. Max penalty Rs 200 cr."),
]
SDF = [
    ("Data Protection Officer", "s. 10(2)(a)", "Appoint India-based DPO, responsible to Board of Directors; grievance point of contact."),
    ("Independent data auditor", "s. 10(2)(b)", "Appoint independent auditor to evaluate compliance."),
    ("DPIA", "s. 10(2)(c)(i), Rule 13", "Periodic (annual) DPIA; report significant observations to the Board."),
    ("Periodic audit", "s. 10(2)(c)(ii), Rule 13", "Annual audit."),
    ("Algorithmic due diligence", "Rule 13", "Verify algorithmic software (incl. AI) does not risk Data Principals' rights."),
    ("Localisation readiness", "Rule 13", "Be able to keep specified personal/traffic data in India if required. Max penalty Rs 150 cr."),
]
CONSENT_MANAGER = [
    ("Registration", "s. 6(9), Rule 4", "Register with Board; meet eligibility and technical/financial conditions."),
    ("Fiduciary duty", "s. 6(8), Rule 4", "Act on behalf of Data Principal; avoid conflicts; keep consent records (~7 years); interoperable platform."),
    ("Grievance", "s. 13", "Grievance redressal for acts/omissions of the Consent Manager."),
]
CROSS_BORDER = [
    ("Transfer inventory", "s. 16(1)", "List every destination country incl. backups, vendor support access, LLM APIs, CDNs, logs."),
    ("Sectoral localisation", "s. 16(2)", "Check RBI/SEBI/IRDAI/telecom/government requirements that override."),
    ("Switchability", "s. 16(1)", "Design to re-route or stop flows if a country is notified as restricted."),
]
ENGINEERING = [
    ("Data catalog / RoPA", "s. 8(4), 8(6), 11", "Inventory systems, data, purposes, basis, retention, regions, Processors; automated PII discovery."),
    ("Purpose enforcement (PDP/PEP)", "s. 4-7", "Runtime check of purpose + basis + child flag on access."),
    ("Consent service & ledger", "s. 6", "Versioned notices, append-only consent events, APIs for Consent Managers."),
    ("Privacy event bus", "s. 6(6), 8(7)", "Outbox + idempotent consumers for withdrawal/erasure/correction events with acks."),
    ("DSR orchestrator", "s. 11-14", "Identity verification, fan-out, SLA timers, templated responses."),
    ("Retention engine", "s. 8(7)-(8)", "Purpose/activity-based expiry, legal holds, pre-erasure notices."),
    ("Estate-wide erasure", "s. 8(7), 12(3)", "OLTP, replicas, caches, search, streams, warehouse time-travel, backups (crypto-shred), Processors."),
    ("Logging", "Rule 6/8", ">= 1 year processing & security logs; no raw sensitive identifiers in logs."),
    ("Non-production data", "s. 8(5)", "Masked or synthetic data in dev/test/UAT and platform clones."),
    ("Region pinning", "s. 16", "Primary, DR, backups and keys in approved regions."),
]
AI = [
    ("AI data provenance", "s. 3(c)(ii), 4", "Basis for training data; public-data carve-out only if made public by the Data Principal/legal duty."),
    ("Embeddings/RAG erasure", "s. 8(7), 12(3)", "subject_id metadata on vectors; delete on erasure; authorisation-filtered retrieval."),
    ("LLM vendor terms", "s. 8(2), 16", "Processor contract, no training on your data, retention limits, region."),
    ("Agent guardrails", "s. 8(4)-(5)", "Purpose-scoped tool permissions, DLP on outputs, audit logs, human approval for high-impact actions."),
    ("Automated decisions", "s. 8(3)", "Accuracy and bias testing; human review for significant decisions."),
]
WEB = [
    ("Privacy notice page", "s. 5, Rule 3", "Itemised data/purposes, withdrawal, rights, grievance contact, Board complaint route; language options."),
    ("Consent banner gates scripts", "s. 6(1), 6(4)", "Analytics/marketing/replay scripts load only after consent; Reject as easy as Accept; footer Privacy settings link."),
    ("Consent evidence", "s. 6(10)", "Store choices server-side with banner/notice version, language, timestamp."),
    ("Minimal forms", "s. 6(1)", "Only necessary fields; separate unticked marketing opt-in; no Aadhaar unless legally permitted."),
    ("Auth hygiene", "s. 8(5)", "Argon2id/bcrypt passwords; hashed OTPs with expiry; HttpOnly Secure SameSite cookies; MFA for admins."),
    ("API authorisation", "s. 8(5)", "Object-level ownership checks on every endpoint; field allow-lists; rate limits; no PII in URLs."),
    ("Field encryption", "s. 8(5)", "Encrypt sensitive fields (phone, IDs, bank, health, location); HMAC index for lookups; keys in KMS."),
    ("Privacy settings page", "s. 6(4), 11-14", "Consent toggles, data summary, edit, delete account, nominee, grievance form."),
    ("Delete-account job", "s. 8(7), 12(3)", "Erase DB rows, files, search, caches, vendor records; crypto-shred backups; keep legally required records only."),
    ("Retention job", "s. 8(7)-(8), 8(11)", "Purge inactive users/leads; count only user-initiated activity; pre-erasure notice where Rules require."),
    ("Log redaction & retention", "Rule 6", "Redact secrets/IDs; error tracker scrubbing; security logs >= 1 year; CERT-In 180 days in India."),
    ("Third-party vendors", "s. 8(2), 16", "DPA, region, deletion method and breach SLA for hosting, email/SMS, payments, analytics, LLM APIs."),
    ("Payments", "s. 8(5)", "Gateway tokenisation/hosted checkout; never store card numbers."),
    ("Uploads", "s. 8(5), 8(7)", "Private bucket, signed URLs, per-user prefix, EXIF stripping, lifecycle rules."),
    ("Non-prod data", "s. 8(5)", "Synthetic/masked data in dev/staging; restricted prod DB access."),
    ("Security headers", "s. 8(5)", "CSP, SRI for third-party scripts, HSTS; dependency and secret scanning in CI."),
    ("DPO/contact in footer", "s. 8(9)", "Published business contact for privacy questions."),
]
STATE_NOTE = "State processing: s. 8(7) and 12(3) do not apply; 12(2) does not apply where no decision affecting the Data Principal (s. 17(4)). Check s. 7(b)-(c) and any s. 17(2)(a) notification."
STARTUP_NOTE = "Notified startup/Fiduciary under s. 17(3): s. 5, 8(3), 8(7), 10 and 11 do not apply - confirm notification covers you. Security, breach, consent, children, grievance still apply."
PROCESSOR_ROLE = [
    ("Know your role", "s. 2(k), 8(1)", "Processors have no direct statutory duties; obligations flow via Fiduciary contracts."),
    ("Instruction-only processing", "s. 8(2)", "Process only on documented instructions; no own-purpose use or model training."),
    ("Security", "s. 8(5)", "Meet Rule 6-level safeguards; clients will audit."),
    ("Fast breach notice to client", "s. 8(6)", "Notify client within contract SLA (often 6-24h) with Rule 7 details."),
    ("Cease/erase on instruction", "s. 6(6), 8(7)(b)", "Tenant/subject-level deletion incl. backups; deletion certificates."),
    ("Rights assistance", "s. 11-12", "APIs/SOPs to export, correct, erase per subject."),
    ("Offshore exemption", "s. 17(1)(d)", "Non-Indian residents' data under foreign contract: Ch II-III largely exempt; security still applies."),
]


def section(title, rows):
    out = [f"\n## {title}\n", "| # | Item | Section / Rule | Requirement | Status | Owner |", "|---|---|---|---|---|---|"]
    for i, (item, sec, req) in enumerate(rows, 1):
        out.append(f"| {i} | {item} | {sec} | {req} | [ ] | |")
    return "\n".join(out)


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--role", choices=["fiduciary", "processor"], default="fiduciary")
    p.add_argument("--processors", action="store_true", help="Uses Data Processors / vendors")
    p.add_argument("--children", action="store_true", help="Processes data of under-18s or persons with disability with guardian")
    p.add_argument("--sdf", action="store_true", help="Notified (or likely) Significant Data Fiduciary")
    p.add_argument("--consent-manager", action="store_true", help="Operating as a Consent Manager")
    p.add_argument("--cross-border", action="store_true", help="Data leaves India")
    p.add_argument("--engineering", action="store_true", help="Include architecture/engineering controls")
    p.add_argument("--web", action="store_true", help="Include web application build checklist")
    p.add_argument("--ai", action="store_true", help="Uses AI/ML/LLMs/agents on personal data")
    p.add_argument("--state", action="store_true", help="Processing by the State or its instrumentality")
    p.add_argument("--startup-exempt", action="store_true", help="Notified under s. 17(3)")
    p.add_argument("--org", default="[Organisation]")
    p.add_argument("-o", "--output", help="Write to file instead of stdout")
    a = p.parse_args()

    parts = [f"# DPDP Act 2023 Checklist - {a.org}",
             "_Generated checklist. Verify Rules dates/thresholds on meity.gov.in. Not legal advice._"]
    if a.role == "processor":
        parts.append(section("Data Processor obligations (contractual)", PROCESSOR_ROLE))
    else:
        base = BASE
        if a.startup_exempt:
            skip = {"s. 5(1), 5(3), Rule 3", "s. 5(2)", "s. 8(3)", "s. 11"}
            base = [r for r in BASE if r[1] not in skip]
            parts.append(f"\n> {STARTUP_NOTE}")
        if a.state:
            parts.append(f"\n> {STATE_NOTE}")
        parts.append(section("Core Data Fiduciary obligations", base))
        if a.processors:
            parts.append(section("Processors & sharing", PROCESSORS))
        if a.children:
            parts.append(section("Children & persons with disability", CHILDREN))
        if a.sdf and not a.startup_exempt:
            parts.append(section("Significant Data Fiduciary", SDF))
        if a.cross_border:
            parts.append(section("Cross-border transfer", CROSS_BORDER))
    if a.consent_manager:
        parts.append(section("Consent Manager", CONSENT_MANAGER))
    if a.web:
        parts.append(section("Web application build", WEB))
    if a.engineering:
        parts.append(section("Architecture & engineering controls", ENGINEERING))
    if a.ai:
        parts.append(section("AI / ML / agentic systems", AI))

    text = "\n".join(parts) + "\n"
    if a.output:
        with open(a.output, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"Wrote {a.output}")
    else:
        sys.stdout.write(text)


if __name__ == "__main__":
    main()
