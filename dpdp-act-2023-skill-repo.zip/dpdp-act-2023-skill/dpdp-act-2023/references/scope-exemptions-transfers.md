# Scope, Exemptions and Cross-Border Transfer

## Commencement — s. 1(2)
The Act comes into force on dates notified by the Central Government.
Different dates can apply to different provisions. See `dpdp-rules-2025.md`
for the phased timeline.

## Application — s. 3

**The Act applies to (s. 3(a)–(b)):**
- **(a)** Processing of digital personal data **within India** where the data
  is collected (i) in digital form, or (ii) in non-digital form and
  digitised later.
- **(b)** Processing **outside India** *if* it is connected with any activity
  related to **offering goods or services to Data Principals within India**.

**The Act does NOT apply to (s. 3(c)):**
- **(i)** Personal data processed by an individual for any **personal or
  domestic purpose**.
- **(ii)** Personal data **made publicly available**:
  - (A) by the Data Principal herself; or
  - (B) by any other person under a legal obligation in India to publish it.
  - *Illustration:* X blogs her views and makes her personal data public on
    social media, so the Act does not apply.

### Applicability decision tree

```
Is it personal data (identifiable individual)?            no → out of scope
Is it digital, or digitised later?                         no → out of scope
Is processing wholly/partly automated?                     no → out of scope
Processing in India?  → yes → continue
                      → no  → Is it connected to offering goods/services
                               to people in India?        no → out of scope
Personal/domestic purpose by an individual?               yes → out of scope
Made public by the Data Principal or under legal duty?    yes → out of scope
Any s. 17 exemption?                                      check below
Otherwise → Act applies in full.
```

**Watch-outs:**
- Offshore behavioural monitoring of Indians *without* offering goods or
  services is not caught by s. 3(b). This is narrower than GDPR Art. 3(2)(b).
- The "publicly available" carve-out covers only data made public *by the
  Data Principal* or under a legal duty. Data leaked or scraped from a
  third-party publication is not automatically exempt. Analyse carefully.

## Exemptions — s. 17

### s. 17(1): partial exemption

For the purposes below, **Chapter II (except s. 8(1) and 8(5)), Chapter III,
and s. 16 do not apply**. Accountability (s. 8(1)) and security safeguards
(s. 8(5)) still apply.
- **(a)** Enforcing any legal right or claim.
- **(b)** Processing by a court, tribunal or other body with judicial,
  quasi-judicial, regulatory or supervisory functions, where necessary for
  that function.
- **(c)** Prevention, detection, investigation or prosecution of any offence
  or contravention of Indian law.
- **(d)** Personal data of Data Principals **not within India**, processed
  under a contract with a person outside India by a person based in India.
  This is the **outsourcing / BPO / GCC exemption**.
- **(e)** A court- or authority-approved scheme of compromise, arrangement,
  merger, amalgamation, demerger, or transfer or division of undertakings.
- **(f)** Ascertaining financial information, assets and liabilities of a
  person who has **defaulted on a loan** from a financial institution. The
  terms "default" and "financial institution" follow IBC 2016 s. 3(12) and
  3(14). Other disclosure laws must still be followed.
  - *Illustration:* X defaults on an EMI to bank Y, so Y may process X's
    data to ascertain her assets and liabilities.

### s. 17(2): full exemption (the Act does not apply)
- **(a)** Processing by a State instrumentality notified by the Central
  Government in the interests of:
  - sovereignty and integrity of India;
  - security of the State;
  - friendly relations with foreign States;
  - public order; or
  - preventing incitement to a cognizable offence relating to these.

  Processing by the Central Government of data such an instrumentality
  furnishes is also exempt.
- **(b)** Processing necessary for **research, archiving or statistical
  purposes**, if the data is not used to take any decision specific to a
  Data Principal *and* is carried out per prescribed standards.

### s. 17(3): notified Data Fiduciaries (e.g., startups)

Based on the volume and nature of data, the government may notify Data
Fiduciaries, including **startups**, to whom the following do not apply:
- s. 5 (notice);
- s. 8(3) (accuracy);
- s. 8(7) (erasure);
- s. 10 (SDF);
- s. 11 (right to access).

A "startup" here means a private limited company, partnership firm or LLP
incorporated in India and recognised under DPIIT criteria.

### s. 17(4): processing by the State

For processing by the State or its instrumentalities:
- s. 8(7) (erasure on purpose/withdrawal) does not apply;
- s. 12(3) (right to erasure) does not apply;
- s. 12(2) (correction) also does not apply if the purpose does not include
  making a decision that affects the Data Principal.

### s. 17(5): sunset power

Within **five years** of commencement, the government may declare by
notification that any provision does not apply to specified Data
Fiduciaries for a specified period.

## Cross-border transfer — s. 16
- **s. 16(1):** The Central Government may, by notification, **restrict**
  transfer of personal data to countries or territories it notifies. This is
  a **negative-list (blacklist) model**: transfer is permitted by default.
- **s. 16(2):** Any other Indian law giving a **higher degree of protection
  or restriction** on transfer still prevails. Examples: RBI payment-data
  storage directions, SEBI, IRDAI, and telecom licence conditions.
- These notifications must be laid before Parliament (s. 41).
- Under the Rules, SDFs may additionally be required to keep specified
  personal data and related traffic data in India, per a government
  committee's recommendations. See `dpdp-rules-2025.md`.

## Relationship with other laws — s. 38
- The Act is **in addition to**, not in derogation of, other laws (s. 38(1)).
- On **conflict**, the DPDP Act prevails to the extent of the conflict
  (s. 38(2)). However, s. 16(2) specifically preserves stricter transfer
  restrictions.
