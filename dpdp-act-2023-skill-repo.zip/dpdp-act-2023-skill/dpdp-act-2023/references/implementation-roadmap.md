# DPDP Compliance Programme — Roadmap & Governance

Target: substantive obligations enforceable **~13 May 2027** (Rules
Phase III). Consent Manager rules take effect **~13 Nov 2026**. The Board is
live now. Verify dates. Adjust the phases to the organisation's size.

## Phase 0 — Mobilise (weeks 0–4)
- **Sponsor.** Appoint an executive sponsor and a privacy lead. An SDF also
  needs a DPO based in India, reporting to the board (s. 10(2)(a)).
- **Working group.** Legal, security, engineering, product, HR, marketing,
  procurement and customer support.
- **Scope.** Legal entities, products, and whether you may be an SDF or a
  notified startup.

## Phase 1 — Discover (weeks 2–10)
- **Data inventory / RoPA.** Record systems, data categories, purposes,
  lawful basis (consent or s. 7 clause), retention, Processors, regions and
  sharing. Use `assets/ropa-template.csv`.
- **Automated PII discovery** across databases, object stores, SaaS and
  endpoints.
- **Children.** Identify where children's data exists.
- **Contracts.** Inventory Processor contracts.
- **Legacy consents.** Find all consents obtained pre-commencement. They
  need notices under s. 5(2).

## Phase 2 — Assess (weeks 8–14)
- **Gap assessment** against the checklist. Run
  `scripts/dpdp_checklist.py`, and use `assets/gap-assessment-template.md`.
- **DPIA** for high-risk processing. Mandatory and periodic for SDFs, and
  good practice otherwise (`assets/dpia-template.md`).
- **Datastore assessment.** Run `scripts/datastore_assessment.py` on the
  inventory.
- **Risk-rank the gaps** by Schedule penalty exposure and likelihood.

## Phase 3 — Design & build (months 3–15)

| Workstream | Deliverables |
|---|---|
| Notice & consent | Itemised multilingual notices; consent ledger; withdrawal UX; legacy-user notice campaign; Consent Manager integration readiness |
| Lawful-basis register | Each purpose mapped to consent or a s. 7 clause; runtime enforcement |
| Rights & grievance | DSR portal and orchestrator; identity verification; nomination; ≤90-day grievance SLA; published DPO contact |
| Security | Rule 6 controls; logging ≥1 year; encryption and tokenisation; PAM; DLP |
| Breach response | Two-stage runbook; notice templates; Board submission process; CERT-In alignment; tabletop |
| Retention & erasure | Retention schedule; retention engine; backup strategy (crypto-shred); 48h pre-erasure notices where applicable |
| Children | Age assurance; verifiable parental consent; tracking and ad suppression |
| Processors | DPA addenda; sub-processor register; deletion and breach SLAs |
| Cross-border | Transfer register; region pinning; sectoral localisation check |
| AI | Model and data inventory; RAG/embedding erasure; LLM vendor terms; agent guardrails |

## Phase 4 — Operate (ongoing)
- **Policies.** Privacy policy (external), data protection policy, retention
  policy, breach policy, and acceptable-use policy.
- **Training.**
  - All staff: annual.
  - Engineers: secure and privacy-by-design practice.
  - Support staff: rights requests and grievances.
- **Metrics.**
  - Rights requests: volume and SLA.
  - Grievances: count and SLA.
  - Withdrawal propagation time.
  - Erasure completion rate.
  - Breach intimation times.
  - Processor acknowledgement rate.
- **Assurance.** Internal audit annually. For an SDF: independent data
  auditor, annual DPIA and audit (s. 10, Rule 13).
- **Change management.**
  - A privacy review gate in the SDLC and procurement.
  - ADR prompts (see architecture reference §11).

## RACI (typical)

| Activity | Accountable | Responsible | Consulted |
|---|---|---|---|
| RoPA & lawful basis | Privacy lead/DPO | Business owners | Legal |
| Notices & consent UX | Product | Engineering, Design | Legal, Privacy |
| Security safeguards | CISO | SecOps, Engineering | Privacy |
| Breach notification | DPO/Privacy lead | CISO, Comms | Legal, Execs |
| Rights & grievances | DPO/Privacy lead | Support ops | Engineering |
| Processor contracts | Legal | Procurement | Privacy, Security |
| Retention & erasure | Data owner | Data engineering | Legal (holds) |
