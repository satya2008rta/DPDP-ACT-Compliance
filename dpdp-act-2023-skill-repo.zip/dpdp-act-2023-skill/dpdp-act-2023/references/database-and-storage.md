# Choosing and Designing Databases & Storage for DPDP

There is no "DPDP-certified database". What matters is whether the data
estate as a whole can do the following:
- enforce purpose-based access;
- protect data (s. 8(5));
- keep ≥1-year logs (Rule 6/8);
- erase a single person's data everywhere, including Processors (s. 8(7),
  s. 12(3));
- find everyone affected by a breach (s. 8(6));
- stay in chosen regions (s. 16, sectoral rules).

Choose engines for the workload first. Then verify each engine against the
criteria below, and design the gaps closed.

## Contents
1. Selection criteria mapped to the Act
2. Engine-by-engine notes
3. Decision guide by workload
4. Erasure across the whole estate (the hard part)
5. Schema and key-management patterns
6. Analytics, warehouse and lake
7. Logs, observability and backups
8. Anti-patterns

---

## 1. Selection criteria mapped to the Act

| # | Criterion | Why (Act/Rules) | What to verify |
|---|---|---|---|
| C1 | Encryption at rest with customer-managed keys | s. 8(5), Rule 6 | KMS/HSM integration, key rotation, per-tenant keys |
| C2 | Field / column-level encryption or tokenisation | s. 8(5); limits breach scope (s. 33(2)(b)) | Native (e.g., Always Encrypted, CSFLE/Queryable Encryption) or app-layer |
| C3 | Fine-grained access control | s. 8(4)–(5), purpose limitation | Row-level security, column masking, ABAC hooks |
| C4 | Audit logging of access to personal data | Rule 6 logs, s. 6(10) evidence, breach forensics | Native audit (pgaudit, SQL Server Audit, Oracle Unified Auditing, Atlas auditing) exported to SIEM, ≥1 yr |
| C5 | Point deletion that is actually physical | s. 8(7), 12(3) | Tombstones and compaction, vacuum, time-travel and fail-safe windows, replica lag |
| C6 | TTL / scheduled expiry | s. 8(7)–(8), Rule 8 | Native TTL (DynamoDB, Cosmos DB, MongoDB, Cassandra, Redis) or partition drop |
| C7 | Backup erasure strategy | s. 8(7) (backups are "processing" → storage) | Backup retention length, restore-then-reapply-deletes process, or crypto-shredding |
| C8 | Region pinning, incl. backups and replicas | s. 16, sectoral localisation, Rule 13 | India regions for primary, DR, backup, and support access |
| C9 | Change data capture that carries deletes | Erasure propagation | CDC emits deletes; downstream consumers honour tombstones |
| C10 | Discoverability of PII | s. 8(6), s. 11 | Works with catalog/PII scanners; schema metadata/comments |
| C11 | Integrity / immutability where needed | s. 6(10) proof of consent | Append-only tables, ledger features, WORM storage — **without** raw PII |
| C12 | Operational maturity | s. 8(5) reasonable safeguards | Patching, HA, managed service certs (ISO 27001, SOC 2), vendor as Processor contract |

## 2. Engine-by-engine notes
(Capabilities evolve. Confirm features and editions for your version or
tier.)

**Relational (OLTP)**

| Engine | Strengths for DPDP | Watch-outs |
|---|---|---|
| **PostgreSQL** (self-managed, RDS/Aurora, Azure Flexible, Cloud SQL, AlloyDB) | Row-Level Security; `pgcrypto`; `pgaudit`; partitioning (drop old partitions = cheap retention); logical decoding/CDC with deletes; strong fit for consent ledger | No native TDE in community build (rely on disk/managed encryption + app-layer field encryption); `DELETE` needs VACUUM for physical removal; PITR backups retain deleted rows until window expires |
| **MySQL / MariaDB** | Mature, cheap, managed everywhere; InnoDB tablespace encryption; binlog CDC | Column-level security weaker; audit plugins vary by edition; binlogs contain PII — set retention |
| **SQL Server / Azure SQL** | TDE, Always Encrypted (client-side keys), Dynamic Data Masking, Row-Level Security, SQL Audit, ledger tables | Ledger tables are append-only — never put PII in them unencrypted; licensing cost |
| **Oracle** | TDE, Data Redaction, VPD/row security, Unified Auditing, Data Safe | Cost/complexity; ensure redaction isn't mistaken for protection at rest |

**NoSQL / key-value**

| Engine | Strengths | Watch-outs |
|---|---|---|
| **MongoDB / Atlas** | CSFLE & Queryable Encryption, TTL indexes, Atlas region pinning & auditing | Denormalised copies of PII across documents complicate erasure; oplog retention |
| **DynamoDB** | Item TTL, KMS CMK, Streams (deletes visible), India regions | PITR (up to 35 days) retains deleted items; TTL deletion is asynchronous |
| **Cosmos DB** | TTL, CMK, change feed, India regions | Change feed doesn't emit deletes in all modes — use soft-delete + TTL pattern; verify mode |
| **Cassandra / ScyllaDB** | TTL per cell, high write scale | Tombstones persist until gc_grace + compaction; deletes are not immediate on disk |
| **Redis / Valkey** | TTL on keys; ideal for short-lived sessions/OTP | Persistence files (RDB/AOF) & replicas hold data; don't make it a system of record for PII |

**Search, streaming, vectors, objects**

| Store | Watch-outs |
|---|---|
| **Elasticsearch / OpenSearch** | Deletes are logical until segment merge; snapshots retain data; index PII only if search truly needs it — prefer tokens |
| **Kafka / Kinesis / Event Hubs** | Topic retention = storage of PII; use short retention, compacted topics with tombstones, or tokenised payloads; mirror clusters abroad = transfer |
| **Vector DBs / embeddings** (pgvector, OpenSearch k-NN, Pinecone, etc.) | Embeddings of personal content can be personal data (re-identifiable, linked to subject); store `subject_id` metadata so you can delete vectors on erasure; check vendor region |
| **Object storage (S3, Blob, GCS)** | Versioning and Object Lock/WORM block erasure — scope them to non-PII or encrypted-per-subject objects; lifecycle rules for retention; replication rules can cross borders |

**Warehouse / lakehouse**

| Platform | Watch-outs |
|---|---|
| **Snowflake** | Time Travel (up to 90 days on higher editions) + Fail-safe (7 days) keep deleted data; set Time Travel low on PII tables; use masking & row access policies |
| **BigQuery** | Time travel window (configurable, days) + fail-safe; column-level security & policy tags; dataset location = region |
| **Databricks / Delta Lake, Iceberg, Hudi** | Deleted rows remain in old files until `VACUUM`/expiry; set retention; use deletion vectors carefully; Unity Catalog tags for PII |
| **Redshift / Synapse / Fabric** | Snapshots retain data; confirm region of snapshots |

## 3. Decision guide by workload

| Workload | Recommended default | DPDP design notes |
|---|---|---|
| Consent ledger & notice versions | PostgreSQL (or SQL Server) | Append-only table + hash chain; no raw PII beyond `subject_id`; long retention as evidence (align with limitation period & Rules) |
| Customer/subject profile (system of record for PII) | PostgreSQL / SQL Server / Aurora with field encryption | Single place for direct identifiers; others hold tokens |
| High-scale user activity/events | DynamoDB / Cassandra / Bigtable / Kafka | Store tokens not identifiers; TTL aligned to purpose |
| Sessions, OTPs, rate limits | Redis with TTL | No long-term PII |
| Documents / KYC images | Object storage + per-object encryption keys | Lifecycle rules; no Object Lock unless legally required retention (then legal hold + expiry) |
| Search | OpenSearch/Elastic | Index minimum fields; reindex on erasure |
| Analytics / BI | Warehouse with pseudonymised subject key | Aggregate or pseudonymise at ingestion; re-identification only via controlled join |
| ML feature store / training | Lakehouse with lineage | Track which subjects' data trained which model (see `ai-ml-and-agentic-systems.md`) |
| Audit & security logs | SIEM / log store, ≥1 year | Minimise PII in logs; restrict access; region |

**Rule of thumb:** keep *one* system of record for direct identifiers, let
everything else reference a token, and design erasure as a first-class
feature.

## 4. Erasure across the whole estate

Erasure obligations arise from:
- consent withdrawal or end of purpose (s. 8(7));
- a Data Principal's request (s. 12(3));
- inactivity periods (s. 8(8), Rule 8).

Each has exceptions for legal retention and continuing purpose.

**Erasure matrix.** Fill this in for every system.

| Layer | Mechanism | Max lag | Evidence |
|---|---|---|---|
| OLTP primary | Hard delete, or anonymise in place (keep aggregates) | minutes | row count / audit entry |
| Replicas, caches | Replication + cache invalidation event | minutes | — |
| Search index | Delete by `subject_id`, or reindex | hours | API response |
| Streams | Short retention, or tombstones | retention window | config |
| Warehouse/lake | Delete + vacuum/expire time travel | days | job log |
| Backups | **Option A:** expire naturally (short retention) and re-apply the deletion log on any restore. **Option B:** crypto-shredding (destroy the per-subject key) | backup retention / immediate | key destruction log |
| Processors | API or SOP via Processor Connector | contract SLA | vendor attestation |
| Logs | Minimise PII upfront. Logs kept ≥1 yr for security are a legal-retention use, so restrict access | ≥1 yr | — |

**Crypto-shredding pattern.**
1. Each subject gets a Data Encryption Key (DEK), wrapped by a KMS master
   key.
2. Personal fields are encrypted with the DEK wherever they are stored,
   including events and backups.
3. Erasure destroys the DEK. The ciphertext left in backups and immutable
   logs becomes unreadable.
4. Keep the destruction record.

This is the practical answer for immutable stores and long backups.

**Anonymise vs delete.**
- If you keep records for statistics, **irreversibly** remove or generalise
  identifiers, including quasi-identifiers such as PIN code plus date of
  birth plus gender.
- Pseudonymised data (a token plus a lookup table) is still personal data.

**Legal holds.** Retention required by law overrides erasure (s. 8(7),
s. 12(3)). Examples:
- PMLA/KYC records kept 5 years after the relationship ends;
- tax records;
- banking records (the Act's own illustration cites 10 years).

Tag these with `legal_hold_until` and restrict their use to the legal
purpose only.

## 5. Schema and key-management patterns

**Split tables:**
- `subject` (identifiers, encrypted);
- `subject_contact` (channels needed for breach notices);
- `consent`;
- `processing_basis`;
- domain tables that reference `subject_id` only.

**Metadata.** Use `COMMENT ON COLUMN` tags, or catalog tags such as
`pii:direct`, `pii:quasi`, `purpose:billing`, `retention:P3Y`.

**Row-level security** by tenant and purpose. Use column masking for
support roles.

**Keys:**
- KMS/HSM held in India regions;
- separate keys per environment and tenant;
- rotation;
- break-glass access logged.

**Non-production:**
- masked or synthetic data;
- no production PII in dev or test without the same safeguards;
- mask **before** copying.

See `assets/consent-ledger-schema.sql`.

## 6. Analytics, warehouse and lake
- **Pseudonymise at ingestion.** Replace identifiers with a keyed hash
  (HMAC) per domain, and hold the key outside the warehouse.
- **Purpose on datasets.** Tag each dataset with its purposes. Analytics for
  a new purpose needs its own basis (consent), or must be done on
  **aggregated or anonymised** data.
- **Carry deletes.** Deletes must flow through CDC. Schedule time-travel
  expiry and vacuum on PII tables.
- **Exports.** BI extracts and spreadsheets are shadow copies. Govern them
  with DLP and expiry.

## 7. Logs, observability and backups
- **Minimum retention.** Keep processing logs ≥ 1 year (Rules). Don't keep
  them forever with raw PII.
- **Log content.** Log `subject_id` or tokens, never OTPs, passwords, full
  card numbers, Aadhaar or PAN, or document images.
- **Tracing and APM.** Scrub request bodies and headers.
- **Backups:**
  - encrypted;
  - kept in India regions where required;
  - retention documented and justified;
  - restores tested;
  - erasure-on-restore procedure written down.

## 8. Anti-patterns
- Phone number or email as primary key or foreign key across systems.
- PII in blockchain or other truly immutable ledgers without encryption.
- "Soft delete forever" (`is_deleted=true` with no purge).
- Copying production data to staging "just for testing".
- A single mega-table mixing children's and adults' data with no child flag.
- Global multi-region replication turned on by default for a PII database.
- Snowflake or BigQuery tables with maximum time-travel windows holding raw
  PII.
- Vector stores of customer chats with no `subject_id`, which cannot be
  erased.
