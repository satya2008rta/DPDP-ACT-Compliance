# Definitions — Section 2, DPDP Act 2023

Definitions apply "unless the context otherwise requires". Terms are grouped
by importance; clause letters match the Act.

## Core actors

| Term | Clause | Meaning |
|---|---|---|
| **Data Principal** | 2(j) | The individual to whom the personal data relates. For a **child**, includes the parents or lawful guardian. For a **person with disability**, includes her lawful guardian acting on her behalf. |
| **Data Fiduciary** | 2(i) | Any person who, alone or with others, determines the **purpose and means** of processing personal data. (≈ GDPR "controller") |
| **Data Processor** | 2(k) | Any person who processes personal data **on behalf of** a Data Fiduciary. |
| **Significant Data Fiduciary (SDF)** | 2(z) | Any Data Fiduciary or class notified by the Central Government under s. 10. |
| **Consent Manager** | 2(g) | A person registered with the Board who is a single point of contact enabling a Data Principal to give, manage, review and withdraw consent through an accessible, transparent and interoperable platform. |
| **Data Protection Officer** | 2(l) | Individual appointed by an SDF under s. 10(2)(a). |
| **Board** | 2(c) | Data Protection Board of India (s. 18). |
| **Appellate Tribunal** | 2(a) | Telecom Disputes Settlement and Appellate Tribunal (TDSAT) under s. 14 of the TRAI Act, 1997. |
| **Chairperson / Member** | 2(e), 2(q) | Chairperson of the Board; "Member" includes the Chairperson. |

## Data and processing

| Term | Clause | Meaning |
|---|---|---|
| **data** | 2(h) | A representation of information, facts, concepts, opinions or instructions suitable for communication, interpretation or processing by humans or automated means. |
| **personal data** | 2(t) | Any data about an individual who is **identifiable by or in relation to** such data. |
| **digital personal data** | 2(n) | Personal data in digital form. |
| **processing** | 2(x) | A wholly or partly **automated** operation or set of operations performed on digital personal data. Includes collection, recording, organisation, structuring, storage, adaptation, retrieval, use, alignment or combination, indexing, sharing, disclosure by transmission, dissemination or making available, restriction, erasure or destruction. |
| **automated** | 2(b) | Any digital process capable of operating automatically in response to instructions or otherwise for processing data. |
| **personal data breach** | 2(u) | Any unauthorised processing, or accidental disclosure, acquisition, sharing, use, alteration, destruction or loss of access to personal data, that compromises its **confidentiality, integrity or availability**. |
| **specified purpose** | 2(za) | The purpose mentioned in the notice given by the Data Fiduciary to the Data Principal under the Act and Rules. |
| **certain legitimate uses** | 2(d) | The uses listed in s. 7. |

## People and entities

| Term | Clause | Meaning |
|---|---|---|
| **child** | 2(f) | An individual who has **not completed 18 years**. |
| **person** | 2(s) | Includes (i) an individual, (ii) a Hindu undivided family, (iii) a company, (iv) a firm, (v) an association of persons or body of individuals, incorporated or not, (vi) the State, and (vii) every artificial juristic person not covered above. |
| **State** | 2(zb) | As defined in Article 12 of the Constitution. |
| **she** | 2(y) | Refers to an individual irrespective of gender. The Act uses "her/she" throughout. |

## Procedural

| Term | Clause | Meaning |
|---|---|---|
| **digital office** | 2(m) | An office where proceedings, from receipt of intimation, complaint, reference, direction or appeal through to disposal, are conducted online or digitally. |
| **gain** | 2(o) | A gain in property or supply of services (temporary or permanent), or an opportunity to earn (greater) remuneration or gain a financial advantage other than legitimate remuneration. |
| **loss** | 2(p) | A loss in property or interruption in supply of services (temporary or permanent), or loss of such an opportunity. |
| **notification** | 2(r) | Published in the Official Gazette. "notify" and "notified" follow. |
| **prescribed** | 2(v) | Prescribed by Rules made under the Act. |
| **proceeding** | 2(w) | Any action taken by the Board under the Act. |

## Interpretation notes

- **Non-automated processing is out of scope.** "Processing" must be wholly
  or partly automated, so purely manual handling of paper files that are
  never digitised falls outside the Act.
- **Anonymised data.** The Act has no separate definition. If an individual
  is no longer identifiable "by or in relation to" the data, it is not
  personal data.
- **No sensitive data tier.** There is no "sensitive personal data" or
  "critical personal data" category, unlike the 2019 PDP Bill and GDPR
  Art. 9.
- **Parents and guardians are Data Principals.** Because the definition
  includes parents or guardians, they can exercise the child's rights.
