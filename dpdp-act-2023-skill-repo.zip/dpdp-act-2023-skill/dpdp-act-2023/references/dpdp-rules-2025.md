# DPDP Rules, 2025 — Working Summary

> **Accuracy notice.** The Act text in this skill comes from the official
> Gazette. This file is a **working summary** of the Rules, compiled from
> public commentary after notification. Rule numbers, thresholds and
> timelines should be **verified against the official Rules on
> meity.gov.in** before being given as definitive advice. Search the web if
> you have the tool. Amendments or clarifications may also have been issued
> since this summary was written.

## Notification and phased commencement

The Rules were notified by MeitY on **13 November 2025** under s. 40 of the
Act.

| Phase | Effective | What commences |
|---|---|---|
| I | On publication (13–14 Nov 2025) | Rules 1–2 (title, definitions) and Rules 17–21 (Data Protection Board). The corresponding Act provisions, including the RTI amendment, also commence. |
| II | +12 months (~13 Nov 2026) | Rule 4: Consent Manager registration and obligations. |
| III | +18 months (~13 May 2027) | Rules 3, 5–16, 22–23: the substantive obligations of Data Fiduciaries. |

Practical point: the Board already exists. Most Fiduciary obligations become
enforceable in Phase III, so organisations should be building compliance now.

## Key operational requirements (Phase III unless noted)

**Notice (Rule 3, implementing s. 5).** The notice must be:
- **standalone**, i.e., understandable independently of other information;
- in clear and plain language;
- an **itemised** description of the personal data;
- a statement of the specified purpose(s);
- a description of the goods, services or uses enabled;
- a communication link for withdrawal (as easy as giving consent), for
  exercising rights, and for complaining to the Board.

**Consent Managers (Rule 4, Phase II).**
- Registration with the Board, subject to eligibility conditions (including
  being an Indian company and meeting net-worth and technical requirements).
- Duty to act for the Data Principal, avoid conflicts of interest, and keep
  consent records for about **7 years**.

**Security safeguards (Rule 6, implementing s. 8(5)).** Minimum reasonable
safeguards include:
- encryption, obfuscation, masking or virtual tokens;
- access controls;
- logging and monitoring to detect unauthorised access;
- backups and continuity measures;
- **retention of logs and related data for at least one year**;
- appropriate contract clauses with Processors.

**Breach intimation (Rule 7, implementing s. 8(6)).** A two-stage process
with **no harm or risk threshold**:
1. **Without delay**, notify each affected Data Principal and the Board. The
   notice covers the nature, extent, timing and location of the breach,
   likely consequences, mitigation measures, safety steps she can take, and
   a contact point.
2. **Within 72 hours** of becoming aware (extendable by the Board on
   request), send the Board a detailed report covering:
   - updated facts, circumstances and causes;
   - mitigation and remedial measures;
   - findings on who caused it;
   - preventive measures;
   - a report on the notices sent to Data Principals.

**Retention and erasure (Rule 8 + Third Schedule, implementing s. 8(7)–(8)).**
- Certain large platforms must erase personal data after **three years** of
  the Data Principal's inactivity. These are e-commerce entities, online
  gaming intermediaries and social media intermediaries above user
  thresholds (e.g., 2 crore or 50 lakh registered users, by category).
  Legal-retention exceptions apply.
- Erasure requires **at least 48 hours' prior notice** to the Data
  Principal, so she can log in or otherwise act to keep her account.
- Irrespective of erasure, keep personal data, traffic data and logs of
  processing for **at least one year** for the purposes in the Seventh
  Schedule.

**Contact details (Rule 9, implementing s. 8(9)).** Prominently publish the
DPO's or authorised person's business contact on the website and app, and
in every response to a Data Principal.

**Verifiable parental consent (Rule 10, implementing s. 9(1)).**
- Use due diligence to check that the person identifying as the parent is
  an identifiable **adult**.
- Verification may rely on reliable identity and age details already held,
  or on details or tokens issued by an authorised entity such as a Digital
  Locker service.

**Guardians of persons with disability (Rule 11).** Verify that the
guardian is appointed by a court or under applicable law.

**Children's exemptions (Rule 12 + Fourth Schedule, implementing s. 9(4)).**
Exempted classes and purposes include:
- clinical establishments and healthcare professionals (health services);
- educational institutions (educational activities, and safety tracking);
- creche and childcare providers;
- transport for children (location tracking for safety);
- specified purposes such as issuing an email account, ensuring content is
  not detrimental, or confirming a user is not a child.

These are limited to what is necessary.

**Significant Data Fiduciaries (Rule 13, implementing s. 10).**
- An **annual** DPIA and audit, with significant observations reported to
  the Board.
- Due diligence that algorithmic software, including AI, used for processing
  does not risk Data Principals' rights.
- Possible **localisation**: specified personal and traffic data to be
  processed in India, per government committee recommendations.

**Rights of Data Principals (Rule 14, implementing ss. 11–14).**
- Publish the means and any identifiers needed to make requests.
- Respond to **grievances within 90 days** at most.
- Enable nomination.

**Cross-border (Rule 15, implementing s. 16).** Transfers are permitted,
subject to requirements the Central Government may specify by general or
special order on making data available to a foreign State or its agencies.

**Research exemption (Rule 16 + Second Schedule, implementing s. 17(2)(b)).**
Research, archiving and statistics must follow standards such as lawful
processing, purpose limitation, data minimisation, accuracy, reasonable
security, and accountability.

**Board (Rules 17–21), appeals (Rule 22), government calls for information
(Rule 23).** Rule 23 covers information requests under s. 36. Disclosure of
a request may be barred where it would prejudice sovereignty or security.

## "As may be prescribed" tracker (s. 40(2) → Rule)

| s. 40(2) | Topic | Rule (approx.) |
|---|---|---|
| (a)(b) | Notice manner, including legacy notice | 3 |
| (c)(d) | Consent Manager accountability and registration | 4 + First Schedule |
| (e) | State benefits under s. 7(b) | 5 + Second Schedule |
| (f) | Breach intimation | 7 |
| (g) | Deemed end of purpose (inactivity) | 8 + Third Schedule |
| (h) | Publishing DPO contact | 9 |
| (i) | Verifiable consent | 10–11 |
| (j) | Children's exemptions | 12 + Fourth Schedule |
| (k)(l) | DPIA and other SDF measures | 13 |
| (m)(n)(o)(p) | Access and erasure requests, grievance timeline, nomination | 14 |
| (q) | Research standards | 16 + Second Schedule |
| (r)–(w) | Board appointments, service conditions, procedure | 17–21 |
| (x)(y) | Appeals | 22 |
