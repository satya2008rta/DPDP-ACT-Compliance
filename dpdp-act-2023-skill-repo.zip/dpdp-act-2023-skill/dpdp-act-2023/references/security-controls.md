# Security Controls — "Reasonable Security Safeguards" (s. 8(5), Rule 6)

Section 8(5) carries the **highest penalty (₹250 crore)**. The Act does not
define "reasonable". Rule 6 sets minimums, and the Board will weigh the
factors in s. 33(2). The practical benchmark is a recognised framework (ISO/IEC
27001 & 27701, NIST CSF, CIS Controls), applied proportionately to the volume
and sensitivity of the data.

## Rule 6 minimums → controls

| Rule 6 theme | Concrete controls |
|---|---|
| Encryption / obfuscation / masking / virtual tokens | TLS 1.2+ everywhere; encryption at rest with KMS; field-level encryption or tokenisation for Aadhaar/PAN/bank/card/health/biometrics/precise location; masking in UIs and non-prod |
| Access control | SSO + MFA; least privilege; RBAC/ABAC with purpose; PAM for admins; quarterly access reviews; joiner-mover-leaver automation |
| Visibility of access (logs, monitoring, review) | Centralised logging of access to personal data (DB audit, app audit, cloud trail); SIEM correlation; UEBA/anomaly alerts; retain ≥ 1 year |
| Continuity (backups, restore) | Encrypted backups; tested restores; RPO/RTO defined; DR in approved regions |
| Retention of logs/data for detection & remediation | ≥ 1 year for logs & related personal data per Rules; documented |
| Contractual safeguards with Processors | DPA clauses (see `assets/processor-contract-clauses.md`); security annex; audit rights; breach notice SLA |
| Technical & organisational measures to ensure observance | Policies, training, secure SDLC, DPIA, vendor risk mgmt |

## Control families

**Identity & access.**
- Service-to-service authentication (mTLS or workload identity).
- No shared accounts.
- Just-in-time admin access.
- Support tools show masked PII by default, with reason-coded unmasking that
  is logged.

**Application security.**
- Threat modelling that includes privacy threats (LINDDUN).
- SAST, DAST and SCA in CI.
- Secrets in a vault.
- Controls against the OWASP Top 10 and API Top 10, especially broken
  object-level authorisation, which is the most common cause of mass PII
  exposure.

**Data security.**
- Data classification and automated PII discovery.
- DLP on email, endpoints and SaaS.
- Watermarked exports.
- Egress controls.

**Infrastructure.**
- CIS-hardened images and patch SLAs.
- Network segmentation, with PII databases in private subnets.
- WAF and DDoS protection.
- CSPM for misconfigured buckets.

**Vendor / Processor risk.**
- Due diligence before onboarding.
- Sub-processor visibility.
- Right to audit.
- Offboarding with deletion certificate.

**People.**
- Privacy and security training.
- Confidentiality undertakings.
- Background checks where lawful (s. 7(i)).

**Non-production.**
- Masked or synthetic data.
- No copying of production PII to dev, test or UAT without equivalent
  controls.

**Detection & response.**
- A playbook aligned to Rule 7's two stages. Pre-draft notices in English
  plus major user languages.
- Tabletop exercises twice a year.
- Coordinate with **CERT-In**. Its directions (April 2022) separately
  require reporting specified cyber incidents **within 6 hours** and keeping
  ICT logs for 180 days in India. DPDP obligations are **in addition** to
  these (s. 38(1)).

## Breach decision aid
Every personal data breach must be intimated. The Act has **no risk
threshold** (s. 8(6), s. 2(u)). This covers:
- confidentiality breaches (exposure);
- integrity breaches (unauthorised alteration);
- availability breaches, including ransomware or loss of access, even if
  there is no exfiltration;
- accidental internal disclosure, e.g. an email sent to the wrong recipient.

Timeline to design for:

| When | Action |
|---|---|
| T0 | Detection |
| T0 + hours | Contain. CERT-In report if applicable (6 h). Initial intimation to the Board **and** affected Data Principals "without delay" |
| ≤ T0 + 72 h | Detailed report to the Board (or seek an extension) |
| After | Remediation, root-cause fixes, DPIA update, and evidence for s. 33(2)(e) mitigation credit |

Timeliness and effectiveness of mitigation reduce penalty exposure under
s. 33(2)(e), so keep a timestamped incident log.
