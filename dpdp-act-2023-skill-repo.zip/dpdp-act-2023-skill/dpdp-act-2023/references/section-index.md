# Section Index — DPDP Act 2023 (all 44 sections + Schedule)

| s. | Heading | Chapter | Reference file |
|---|---|---|---|
| 1 | Short title and commencement | I Preliminary | scope-exemptions-transfers |
| 2 | Definitions | I | definitions |
| 3 | Application of Act | I | scope-exemptions-transfers |
| 4 | Grounds for processing personal data | II Obligations of Data Fiduciary | data-fiduciary-obligations |
| 5 | Notice | II | data-fiduciary-obligations |
| 6 | Consent (incl. Consent Managers) | II | data-fiduciary-obligations |
| 7 | Certain legitimate uses | II | data-fiduciary-obligations |
| 8 | General obligations of Data Fiduciary | II | data-fiduciary-obligations; security-controls; database-and-storage |
| 9 | Processing of personal data of children | II | data-fiduciary-obligations; architecture §7 |
| 10 | Additional obligations of Significant Data Fiduciary | II | data-fiduciary-obligations |
| 11 | Right to access information about personal data | III Rights & Duties | data-principal-rights-duties |
| 12 | Right to correction and erasure | III | data-principal-rights-duties |
| 13 | Right of grievance redressal | III | data-principal-rights-duties |
| 14 | Right to nominate | III | data-principal-rights-duties |
| 15 | Duties of Data Principal | III | data-principal-rights-duties |
| 16 | Processing of personal data outside India | IV Special Provisions | scope-exemptions-transfers |
| 17 | Exemptions | IV | scope-exemptions-transfers |
| 18 | Establishment of Board | V Data Protection Board | board-enforcement-penalties |
| 19 | Composition and qualifications | V | board-enforcement-penalties |
| 20 | Salary, allowances, term of office | V | board-enforcement-penalties |
| 21 | Disqualifications | V | board-enforcement-penalties |
| 22 | Resignation and filling of vacancy | V | board-enforcement-penalties |
| 23 | Proceedings of Board | V | board-enforcement-penalties |
| 24 | Officers and employees | V | board-enforcement-penalties |
| 25 | Members and officers to be public servants | V | board-enforcement-penalties |
| 26 | Powers of Chairperson | V | board-enforcement-penalties |
| 27 | Powers and functions of Board | VI Powers, Functions, Procedure | board-enforcement-penalties |
| 28 | Procedure to be followed by Board | VI | board-enforcement-penalties |
| 29 | Appeal to Appellate Tribunal | VII Appeal & ADR | board-enforcement-penalties |
| 30 | Orders of Appellate Tribunal executable as decree | VII | board-enforcement-penalties |
| 31 | Alternate dispute resolution (mediation) | VII | board-enforcement-penalties |
| 32 | Voluntary undertaking | VII | board-enforcement-penalties |
| 33 | Penalties | VIII Penalties & Adjudication | board-enforcement-penalties |
| 34 | Crediting penalties to Consolidated Fund | VIII | board-enforcement-penalties |
| 35 | Protection of action taken in good faith | IX Miscellaneous | board-enforcement-penalties |
| 36 | Power to call for information | IX | board-enforcement-penalties |
| 37 | Power of Central Government to issue directions (blocking) | IX | board-enforcement-penalties |
| 38 | Consistency with other laws | IX | scope-exemptions-transfers |
| 39 | Bar of jurisdiction | IX | board-enforcement-penalties |
| 40 | Power to make rules | IX | board-enforcement-penalties; dpdp-rules-2025 |
| 41 | Laying of rules and certain notifications | IX | board-enforcement-penalties |
| 42 | Power to amend Schedule | IX | board-enforcement-penalties |
| 43 | Power to remove difficulties | IX | board-enforcement-penalties |
| 44 | Amendments to TRAI Act, IT Act, RTI Act | IX | board-enforcement-penalties |
| Sch. | Penalty Schedule (7 items) | — | board-enforcement-penalties; `scripts/penalty_lookup.py` |

## Topic → section quick finder

| Topic | Sections |
|---|---|
| Consent withdrawal | 6(4)–(6), 8(7) |
| Proof of consent | 6(10) |
| Legacy (pre-Act) consent | 5(2) |
| Languages | 5(3), 6(3) |
| Vendor / processor | 2(k), 6(6), 8(1)–(2), 8(5), 8(7)(b) |
| Accuracy | 8(3), 12(2) |
| Security | 8(4)–(5), Sch. item 1 |
| Breach | 2(u), 8(6), 27(1)(a), Sch. item 2 |
| Retention / erasure | 8(7)–(8), 8(11), 12(3), 17(4) |
| Contact / DPO | 2(l), 6(3), 8(9), 10(2)(a) |
| Grievance | 8(10), 13, 27(1)(b) |
| Children | 2(f), 2(j)(i), 9, Sch. item 3 |
| Persons with disability | 2(j)(ii), 9(1) |
| Employment | 7(i) |
| Startups | 17(3) |
| Research | 17(2)(b) |
| Cross-border | 3(b), 16, 17(1)(d) |
| Penalties | 33, 34, 42, Schedule |
| Appeals | 29–30 |
| Blocking of platforms | 37 |
| RTI change | 44(3) |
