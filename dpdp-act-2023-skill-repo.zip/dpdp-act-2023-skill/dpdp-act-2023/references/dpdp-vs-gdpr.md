# DPDP Act 2023 vs EU GDPR — Key Differences

| Topic | DPDP Act 2023 | GDPR |
|---|---|---|
| Scope of data | Digital personal data, or non-digital data later digitised (s. 3(a)); automated processing | All personal data, automated or in filing systems |
| Extraterritorial reach | Offering goods or services to people in India (s. 3(b)) | Offering goods or services **or monitoring behaviour** in the EU |
| Publicly available data | Excluded if made public by the Data Principal or under legal duty (s. 3(c)(ii)) | Still personal data |
| Special categories | **None**; all personal data is treated alike | Art. 9 special categories, Art. 10 criminal data |
| Lawful bases | Consent, or a closed list of "certain legitimate uses" (s. 7) | Six bases, including contract and **legitimate interests** |
| Consent standard | Free, specific, informed, unconditional, unambiguous, clear affirmative action, limited to necessary data (s. 6(1)) | Similar (Art. 4(11), 7) |
| Consent Managers | Statutory, registered intermediaries (s. 6(7)–(9)) | No equivalent |
| Children | **Under 18**; verifiable parental consent; ban on tracking, monitoring and targeted ads (s. 9) | 13–16 for information society services (Art. 8); no blanket ad ban |
| Notice | Short list: data, purpose, rights, Board complaint (s. 5); Eighth Schedule languages | Detailed Art. 13/14 list |
| Rights | Access (summary), correction/completion/update/erasure, grievance, nomination (ss. 11–14) | Adds portability, objection, restriction, and automated-decision rights |
| Duties of individuals | Yes (s. 15), penalty up to ₹10,000 | No |
| Processor obligations | None directly; Fiduciary liable; valid contract (s. 8(1)–(2)) | Direct obligations (Art. 28, 32, etc.) |
| DPO | Only for SDFs, and must be India-based (s. 10) | Required for public bodies, large-scale monitoring, or special data |
| DPIA | SDFs only, periodic, annual under the Rules (s. 10) | For high-risk processing (Art. 35) |
| Records of processing | Not explicit (implied by s. 8(4), 11(1)) | Art. 30 mandatory |
| Breach notification | **All** breaches to the Board **and** each affected person; no threshold (s. 8(6)); detailed report within 72 h (Rules) | To the authority within 72 h unless unlikely to cause risk; to individuals if high risk |
| Cross-border | Allowed unless the country is blacklisted (s. 16) | Adequacy / SCCs / BCRs (Chapter V) |
| Regulator | Data Protection Board: adjudicatory, digital office | Independent supervisory authorities with broad powers |
| Appeals | TDSAT, then Supreme Court (s. 29) | National courts |
| Penalties | Up to ₹250 crore per Schedule item; to the Consolidated Fund (s. 33–34) | Up to €20m or 4% of global turnover |
| Compensation to individuals | **No** (IT Act s. 43A omitted) | Yes (Art. 82) |
| Private right of action | No civil court jurisdiction (s. 39) | Yes |

**Practical takeaways for GDPR-mature organisations:**
- Re-map every "legitimate interests" processing to consent or a s. 7 use.
- Lower the child age assumption to 18, and switch off tracking and
  targeting.
- Make breach notices unconditional, going to the Board and to every
  affected person.
- Add Eighth Schedule language options to notices and consent flows.
- Integrate with Consent Managers when they go live.
- Prepare for an SDF designation: an India-based DPO, an annual DPIA and
  audit, and algorithmic due diligence.
