# Obligations of Data Fiduciary — Chapter II (ss. 4–10)

## Contents
1. Grounds for processing (s. 4)
2. Notice (s. 5)
3. Consent (s. 6)
4. Certain legitimate uses (s. 7)
5. General obligations (s. 8)
6. Children and persons with disability (s. 9)
7. Significant Data Fiduciaries (s. 10)

---

## 1. Grounds for processing — s. 4
Personal data may be processed **only in accordance with the Act** and for
a **lawful purpose** (any purpose not expressly forbidden by law, s. 4(2)).
The processing must rest on one of two grounds:
- **(a) Consent** of the Data Principal; or
- **(b) Certain legitimate uses** (s. 7).

There is no contractual-necessity or legitimate-interests basis as such. Many
such cases fit s. 7(a) (voluntary provision) or s. 7(i) (employment).

## 2. Notice — s. 5
**s. 5(1):** Every consent request must be **accompanied or preceded** by a
notice informing the Data Principal of:
- (i) the personal data and the **purpose** of processing;
- (ii) how to exercise rights under s. 6(4) (withdrawal) and s. 13
  (grievance);
- (iii) how to **complain to the Board**,

in the manner prescribed. Rule 3 requires the notice to be standalone,
itemised, and in plain language.

*Illustration:* In bank video-KYC, the bank must give notice describing the
data and purpose before requesting it.

**s. 5(2), legacy consent:** Where consent was obtained **before
commencement**:
- (a) the Fiduciary must, as soon as reasonably practicable, give a notice
  covering the same three items, describing the data and the purpose *for
  which it has been processed*; and
- (b) it may continue processing until the Data Principal withdraws consent.

*Illustration:* An e-commerce app notifies pre-Act users by email or in-app
notification.

**s. 5(3):** The notice must be accessible in **English or any Eighth
Schedule language** (22 languages), at the Data Principal's option.

Exemption: notified Fiduciaries such as startups under s. 17(3).

## 3. Consent — s. 6

| Sub-section | Rule |
|---|---|
| 6(1) | Consent must be **free, specific, informed, unconditional and unambiguous with a clear affirmative action**, and limited to data **necessary** for the specified purpose. |
| 6(2) | Any part of consent that infringes the Act, Rules or any other law is **invalid to that extent**. |
| 6(3) | The request must be in **clear and plain language**, available in English or Eighth Schedule languages, and give **contact details of the DPO** (if any) or an authorised person. |
| 6(4) | Right to **withdraw at any time**, with ease **comparable** to giving consent. |
| 6(5) | The Data Principal bears the consequences of withdrawal. Withdrawal does not affect the legality of prior processing. |
| 6(6) | On withdrawal, the Fiduciary must, within a reasonable time, **cease processing and cause its Processors to cease**, unless the Act or another law requires or authorises it. |
| 6(7) | Consent may be given, managed, reviewed or withdrawn through a **Consent Manager**. |
| 6(8) | The Consent Manager is accountable to the Data Principal and acts on her behalf as prescribed. |
| 6(9) | Consent Managers must be **registered with the Board**, subject to prescribed conditions. |
| 6(10) | **Burden of proof:** in a proceeding, the Fiduciary must prove that notice was given and consent obtained per the Act. |

**Illustrations:**
- **Over-broad consent (6(1)):** A telemedicine app also asks for access to
  the contact list. Consent is limited to the telemedicine purpose, because
  contacts are not necessary.
- **Rights waiver (6(2)):** An insurance consent that includes a waiver of
  the right to complain to the Board is **invalid** as to that waiver.
- **Withdrawal (6(5)):** After withdrawal, an e-commerce app may stop new
  orders but must still fulfil paid orders.
- **Processor must stop (6(6)):** A telco's customer switches from email
  bills to in-app bills. The telco must stop, and must make its email-billing
  processor stop, processing for email bills.

**Design implications:**
- No pre-ticked boxes, no consent-by-silence, and no bundling of unnecessary
  data.
- Provide a withdrawal path in the same channel with similar friction.
- Keep auditable consent logs, since the burden of proof sits with the
  Fiduciary.

## 4. Certain legitimate uses — s. 7 (closed list)
A Fiduciary may process personal data **without consent** only for these
uses:

**(a) Voluntary provision for a specified purpose.** The Data Principal
voluntarily provides her data for a specified purpose and has not indicated
that she does not consent to its use.
- *Illustration:* A pharmacy customer gives her number for a payment
  receipt, so the pharmacy may SMS the receipt.
- *Illustration:* A person asks a broker to find a rental. When she says she
  no longer needs help, the broker must stop processing.

**(b) State subsidies, benefits and licences.** The State or its
instrumentalities may process data to provide or issue a subsidy, benefit,
service, certificate, licence or permit, where:
- (i) she previously consented to State processing for any such benefit; or
- (ii) the data is in a notified State database.

This is subject to government data-governance policy or standards.
- *Illustration:* Data given for a maternity benefit may be used to
  determine eligibility for other prescribed benefits.

**(c) State functions and security.** Performance by the State of any
function under law, or in the interest of sovereignty, integrity or security
of the State.

**(d) Legal disclosure to the State.** Fulfilling a legal obligation to
disclose information to the State, per the relevant disclosure law.

**(e) Court orders.** Compliance with any Indian judgment, decree or order,
or any foreign judgment or order relating to contractual or civil claims.

**(f) Medical emergency.** A medical emergency involving a threat to life or
an immediate threat to the health of the Data Principal or any other
individual.

**(g) Public health.** Medical treatment or health services during an
epidemic, outbreak or other public-health threat.

**(h) Disaster or public order.** Safety, assistance or services during a
disaster (as defined in Disaster Management Act 2005 s. 2(d)) or a breakdown
of public order.

**(i) Employment.** Purposes of employment, or safeguarding the employer from
loss or liability. Examples include preventing corporate espionage,
confidentiality of trade secrets, IP and classified information, and
providing any service or benefit an employee seeks.

Notes:
- **s. 7(i)** is the main basis for HR processing: payroll, attendance,
  access control, background checks linked to employment, and DLP. Keep the
  processing proportionate and document the purpose.
- For **s. 7(a)**, the purpose must be one the Data Principal would
  understand from the context, and processing must stop once she indicates
  objection.
- Rights under **s. 11 and s. 12** attach to consent **and to s. 7(a)**
  processing only. They do not apply to s. 7(b)–(i).

## 5. General obligations — s. 8

| Sub-s. | Obligation | Practical meaning |
|---|---|---|
| 8(1) | **Accountability**: the Fiduciary is responsible for compliance for processing by itself *or its Processors*, irrespective of any contrary agreement or of the Data Principal's failure to do her duties. | Liability cannot be contracted away to a vendor. |
| 8(2) | Engage a Processor **only under a valid contract**, for activities related to offering goods or services. | A DPA is required. See `assets/processor-contract-clauses.md`. |
| 8(3) | Ensure **completeness, accuracy and consistency** where data is used for a decision affecting the Data Principal, or disclosed to another Fiduciary. | Data quality controls for decisioning (credit, hiring, KYC). |
| 8(4) | **Appropriate technical and organisational measures** for effective observance. | Privacy governance programme. |
| 8(5) | **Reasonable security safeguards** to prevent personal data breach, including for Processor processing. | Encryption, access control, logging, etc. per Rule 6. Highest penalty (₹250 cr). |
| 8(6) | On a **personal data breach**, intimate **the Board and each affected Data Principal**, in the prescribed form and manner. | Rule 7 two-stage process: immediate notice, then a detailed report to the Board within 72 hours. No harm threshold. |
| 8(7) | **Erase** data (and make Processors erase it) on consent withdrawal or once the purpose is no longer served, *whichever is earlier*, unless retention is legally required. | Retention schedules. Exempt for notified startups and the State. |
| 8(8) | The purpose is **deemed no longer served** if the Data Principal neither approaches the Fiduciary for the purpose nor exercises rights for a prescribed period. The period can vary by class and purpose. | Rule 8 / Third Schedule inactivity periods. |
| 8(9) | **Publish business contact information** of the DPO, or of a person who can answer questions about processing. | Prominent on the website and app. |
| 8(10) | Establish an **effective grievance redressal mechanism**. | Rule: respond within 90 days. |
| 8(11) | Clarifies that "not approached" means she did not initiate contact in person or by electronic or physical communication. | Counts toward the 8(8) inactivity clock. |

**Erasure illustrations:**
- After a used-car sale via a marketplace concludes, the platform should no
  longer retain her data.
- When she closes a bank account, the bank retains KYC for 10 years because
  banking law requires it.

## 6. Children and persons with disability — s. 9
- **9(1):** Before processing personal data of a **child** (under 18), or of
  a **person with disability who has a lawful guardian**, obtain
  **verifiable consent of the parent or lawful guardian** in the prescribed
  manner.
- **9(2):** Do not undertake processing **likely to cause any detrimental
  effect on the well-being of a child**.
- **9(3):** **No tracking or behavioural monitoring of children, and no
  targeted advertising directed at children.**
- **9(4):** Sub-sections 9(1) and 9(3) do not apply to prescribed classes of
  Fiduciaries or purposes, subject to conditions. Under the Rules this
  covers, for example, clinical establishments and healthcare professionals,
  educational institutions, childcare and creche providers, and child
  transport, for limited purposes such as safety and tracking location for
  safety.
- **9(5):** The government may notify a **lower age threshold** for a
  specific Fiduciary whose processing of children's data is **verifiably
  safe**, exempting it from 9(1) and/or 9(3) above that age.
- Note that s. 9(2) (no detrimental effect) cannot be exempted.
- **Penalty:** up to **₹200 crore** (Schedule item 3).

## 7. Significant Data Fiduciary — s. 10

**10(1), designation.** The government may notify any Fiduciary or class as
an SDF based on factors including:
- (a) volume and sensitivity of data;
- (b) risk to Data Principals' rights;
- (c) potential impact on sovereignty and integrity of India;
- (d) risk to electoral democracy;
- (e) security of the State;
- (f) public order.

**10(2), additional obligations.** An SDF must:

- **(a) Appoint a Data Protection Officer** who:
  - represents the SDF under the Act;
  - is **based in India**;
  - is responsible to the **Board of Directors** or similar governing body;
  - is the point of contact for grievance redressal.
- **(b) Appoint an independent data auditor** to evaluate compliance.
- **(c) Undertake other measures:**
  - (i) a **periodic Data Protection Impact Assessment (DPIA)**, covering a
    description of rights and purposes, and assessment and management of risk
    to Data Principals' rights, plus prescribed matters;
  - (ii) a **periodic audit**;
  - (iii) other prescribed measures. Under the Rules these include an
    **annual** DPIA and audit, due diligence that algorithmic software does
    not pose risks to Data Principals' rights, and possible data localisation
    of specified data.

**Penalty:** up to **₹150 crore** (Schedule item 4). Notified startups are
exempt from s. 10 under s. 17(3).
