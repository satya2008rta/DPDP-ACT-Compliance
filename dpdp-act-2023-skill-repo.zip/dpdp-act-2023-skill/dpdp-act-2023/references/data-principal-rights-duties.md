# Rights and Duties of Data Principal — Chapter III (ss. 11–15)

**Scope reminder:** The rights of access (s. 11) and of correction and
erasure (s. 12) apply only against a Fiduciary to whom she gave **consent**,
including **s. 7(a)** voluntary provision. They do **not** apply where
processing rests on s. 7(b)–(i), such as employment, a legal obligation, or
a medical emergency.

## Right to access information — s. 11

**s. 11(1).** On request, made in the prescribed manner, the Data Principal
can obtain:
- (a) a **summary** of personal data being processed and the processing
  activities;
- (b) the **identities of all other Data Fiduciaries and Data Processors**
  with whom the data was shared, plus a description of the data shared;
- (c) any other prescribed information.

**s. 11(2).** Clauses (b) and (c) do not apply to sharing with another
Fiduciary **authorised by law** to obtain the data, on its **written
request**, for prevention, detection or investigation of offences or cyber
incidents, or for prosecution or punishment.

**Limits.** This is a "summary", not a full copy. There is no portability
right. Notified startups are exempt (s. 17(3)).

## Right to correction and erasure — s. 12

**s. 12(1).** The Data Principal has a right to **correction, completion,
updating and erasure** of data processed on consent or s. 7(a), following
any procedure under other laws.

**s. 12(2).** On a request, the Fiduciary must:
- (a) **correct** inaccurate or misleading data;
- (b) **complete** incomplete data;
- (c) **update** the data.

**s. 12(3).** On an erasure request (in the prescribed manner), the
Fiduciary must **erase** unless retention is necessary for the **specified
purpose** or for compliance with law.

**State exemption.** The State is exempt from s. 12(3), and from s. 12(2)
where no decision affecting the Data Principal is involved (s. 17(4)).

## Right of grievance redressal — s. 13
- **s. 13(1):** The Data Principal is entitled to **readily available means
  of grievance redressal** from the Data Fiduciary or Consent Manager for any
  act or omission regarding its obligations or her rights.
- **s. 13(2):** The Fiduciary or Consent Manager must respond within the
  **prescribed period**. The Rules set a maximum of **90 days**.
- **s. 13(3):** She must **exhaust** this remedy before approaching the
  Board.

## Right to nominate — s. 14
- **s. 14(1):** She may **nominate** another individual to exercise her
  rights in the event of **death or incapacity**.
- **s. 14(2):** "Incapacity" means inability to exercise rights due to
  unsoundness of mind or infirmity of body.

## Duties of Data Principal — s. 15
A Data Principal must:
- (a) comply with all applicable laws while exercising rights;
- (b) not **impersonate** another person while providing personal data for a
  specified purpose;
- (c) not **suppress material information** when providing data for any
  State-issued document, unique identifier, proof of identity or proof of
  address;
- (d) not register a **false or frivolous** grievance or complaint with a
  Fiduciary or the Board;
- (e) furnish only **verifiably authentic** information when exercising the
  right to correction or erasure.

**Penalty:** up to **₹10,000** (Schedule item 5). Separately, the Board may
warn a complainant or impose **costs** for a false or frivolous complaint
(s. 28(12)).

## Operational playbook for rights requests
1. **Verify identity** proportionately. If a parent or guardian or a nominee
   is acting, verify their authority.
2. **Check the basis.** Rights apply to consent or s. 7(a) processing only.
   Note any s. 17 exemption.
3. **Access requests.** Give a plain-language summary of the data held,
   processing activities, and recipient Fiduciaries and Processors.
4. **Correction requests.** Make the change, and propagate it to Processors
   and recipients where the data feeds decisions (s. 8(3)).
5. **Erasure requests.** Erase unless the purpose is still being served or
   law requires retention. Instruct Processors to erase too. Tell the Data
   Principal what was retained and why.
6. **Respond within the prescribed timeline.** Log the request and the
   outcome.
7. **Tell her how to escalate.** Include the grievance route, and then the
   route to complain to the Board.
