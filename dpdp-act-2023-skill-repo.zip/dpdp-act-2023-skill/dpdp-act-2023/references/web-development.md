# Building DPDP-Compliant Web Applications

A practical guide for web developers building websites, web apps, SaaS
products and their mobile companions used by people in India. Each item
traces to a section of the Act. For system-level design, see
`architecture-privacy-by-design.md`. For database choice, see
`database-and-storage.md`.

## Contents
1. The five things every web app must be able to do
2. Choosing the stack (frameworks, hosting, region)
3. Frontend: forms, cookies, consent banner, third-party scripts
4. Sign-up, login, OTP, sessions
5. Backend and API patterns (with code)
6. Encrypting personal fields (with code)
7. User privacy features: settings, access, correction, delete account
8. Logging, error tracking and monitoring (with code)
9. Email, SMS, WhatsApp, payments, file uploads, maps
10. Children and age gating
11. Environments, testing and CI/CD
12. CMS and no-code sites (WordPress, Shopify, Webflow)
13. Pre-launch checklist

---

## 1. The five things every web app must be able to do

Design these in from day one. Retrofitting them is expensive.

1. **Show a proper notice and collect consent.** Consent must be per
   purpose and recorded with evidence (s. 5, 6, 6(10)).
2. **Let the user withdraw consent as easily as they gave it,** and stop
   the related processing, including at vendors (s. 6(4), 6(6)).
3. **Find, export, correct and delete one user's data** everywhere it lives
   (s. 8(7), 11, 12).
4. **Protect the data and detect misuse.** Use encryption, access control,
   and logs kept for at least one year (s. 8(5), Rule 6).
5. **Know who was affected if something leaks, and notify them.** Notify
   every affected user and the Board (s. 8(6), Rule 7).

If a proposed design makes any of these hard, change the design.

## 2. Choosing the stack

### Frameworks
Any mainstream framework can be compliant. Use its built-in security
features rather than hand-rolling your own.

| Stack | Useful built-ins for DPDP work |
|---|---|
| **Next.js / React + Node (Express, NestJS, Fastify)** | Server components/route handlers keep PII server-side; middleware for purpose checks; `pino` redaction; Node `crypto` for AES-GCM field encryption |
| **Django** | CSRF protection, strong password hashers (Argon2 supported), per-object permissions, management commands for retention jobs, admin with field-level restrictions |
| **Laravel** | `encrypted` Eloquent casts, policies/gates for authorisation, queues for erasure jobs, scheduled tasks for retention |
| **Ruby on Rails** | Active Record Encryption (`encrypts :email`, deterministic option for lookups), `filter_parameters` for log scrubbing, Active Job |
| **Spring Boot** | Spring Security method-level authorisation, JPA attribute converters for encryption, scheduled jobs |
| **ASP.NET Core** | Data Protection API, authorisation policies, EF Core value converters for encryption |

Whatever the stack, keep personal data on the server. Send the browser only
what the current screen needs.

### Hosting and region
- **Prefer India regions** for the database, file storage and backups. Some
  sectoral rules require this, notably RBI rules for payment data. It also
  simplifies future s. 16 restrictions.
  - AWS: Mumbai, Hyderabad.
  - Azure: Pune, Chennai, Mumbai.
  - GCP: Mumbai, Delhi.
- **Check PaaS defaults.** Many serverless and PaaS platforms and managed
  databases default to US or EU regions. Set the function, database, storage
  and log regions explicitly.
- **Transfers abroad are allowed** unless the government restricts a
  country (s. 16). Record every foreign region and vendor in your data
  inventory.

### Database
Use a relational database such as PostgreSQL or MySQL for the user and
consent records. Details are in `database-and-storage.md`. For a typical web
app, the key rules are:
- Use a random `user_id` (UUID) as the key, never an email or phone number.
- Keep identifiers in one `users` table. Other tables reference `user_id`.
- Add `last_active_at` and `deleted_at` columns, and a purge job.
- Encrypt sensitive fields at the application layer (§6).

## 3. Frontend: forms, cookies, consent banner, third-party scripts

### Forms: collect only what the purpose needs (s. 6(1))
- **Mark every field** required or optional. Optional fields must genuinely
  be optional, and their purpose explained.
- **Ask for sensitive data only when needed.** Examples: date of birth,
  gender, address, Aadhaar, PAN.
  - Don't ask for Aadhaar unless a law permits or requires it. The Aadhaar
    Act restricts who may collect and use Aadhaar numbers.
  - Mask Aadhaar and PAN on display.
- **Contact and lead forms:** name plus one contact channel is usually
  enough. Add unticked checkboxes for marketing consent, separate from the
  enquiry.
- **Link the privacy notice** next to the submit button, and log the notice
  version with the submission.

### Cookies and trackers
The Act has no separate cookie rule. But cookies and trackers that collect
personal data (analytics IDs, ad pixels, session replay) are processing that
needs a lawful basis. For non-essential tracking, that basis is **consent**.

| Category | Examples | Basis |
|---|---|---|
| Strictly necessary | session cookie, CSRF token, load balancer, consent choice cookie | Needed to provide the requested service |
| Analytics | GA4, Mixpanel, PostHog, Hotjar, session replay | Consent (or use privacy-friendly aggregate analytics without personal identifiers) |
| Marketing | Meta Pixel, Google Ads, LinkedIn Insight, retargeting | Consent. **Never for children** (s. 9(3)) |
| Functional | chat widget, embedded video, maps | Consent, or load on click |

### Consent banner requirements
- Put **Accept** and **Reject** at equal prominence, with per-category
  toggles, and nothing pre-ticked (s. 6(1)).
- **Offer a language option:** English plus at least the main languages of
  your users. Any Eighth Schedule language must be available on request
  (s. 5(3), 6(3)).
- **Keep a permanent "Privacy settings" link** in the footer, so withdrawal
  is as easy as consent (s. 6(4)).
- **Record the choice** server-side, with user or anonymous ID, categories,
  banner version, and timestamp. This is your evidence (s. 6(10)).

### Load third-party scripts only after consent
Hard-coding tags in `<head>` means they fire before consent. Gate them
instead:

```html
<!-- Tag is inert until consent: type="text/plain" prevents execution -->
<script type="text/plain" data-consent="analytics"
        data-src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXX"></script>
<script type="text/plain" data-consent="marketing">
  /* marketing pixel init code here */
</script>

<script>
  function applyConsent(choices) {            // e.g. {analytics:true, marketing:false}
    document.querySelectorAll('script[data-consent]').forEach(function (s) {
      if (!choices[s.dataset.consent] || s.dataset.loaded) return;
      var el = document.createElement('script');
      if (s.dataset.src) el.src = s.dataset.src; else el.textContent = s.textContent;
      document.head.appendChild(el);
      s.dataset.loaded = '1';
    });
  }

  async function saveConsent(choices) {
    // Keep first-party record of the choice (strictly necessary)
    document.cookie = 'consent=' + encodeURIComponent(JSON.stringify(choices)) +
      '; Max-Age=' + 60 * 60 * 24 * 180 + '; Path=/; Secure; SameSite=Lax';
    // Evidence in your consent ledger (s. 6(10))
    await fetch('/api/consents', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ choices: choices, bannerVersion: 'v3', lang: document.documentElement.lang })
    });
    applyConsent(choices);
  }
</script>
```

Withdrawing consent cannot "unload" an already-running script. Handle it
this way:
1. Save the new choice.
2. Delete the tracker's cookies you can reach.
3. Reload the page.
4. Stop sending events server-side too.

If you use Google tags, use Consent Mode with default `denied`.
Alternatively, use a consent management platform (CMP) that supports
per-category blocking and exports consent logs.

### Other frontend rules
- **Don't store personal data or tokens in `localStorage`** or
  `sessionStorage`. Prefer HttpOnly cookies for sessions.
- **Don't put personal data in URLs or query strings.** They leak into logs,
  analytics, referrers and browser history. Use POST bodies or opaque IDs.
- **Mask inputs in session-replay tools.** Disable replay on pages with
  forms containing personal data.
- **Use Subresource Integrity (SRI)** and a Content Security Policy (CSP)
  for third-party scripts. A compromised script that skims form data is a
  personal data breach (s. 8(5)).

## 4. Sign-up, login, OTP, sessions

**Sign-up.**
- Show the notice before or with the consent request (s. 5).
- Don't bundle marketing consent with account creation.

**Age.** If under-18s could plausibly use the service, add an age question
and a parent-consent path. See §10.

**Passwords.**
- Hash with **Argon2id** or **bcrypt**, never plain SHA or MD5.
- Rate-limit logins.
- Offer MFA, and require it for admins.

**OTP.**
- Store only a **hash** of the OTP, with a short expiry (5–10 minutes) and
  attempt limits.
- Never log OTPs.

**Sessions.**
- Cookies must be `HttpOnly; Secure; SameSite=Lax` (or `Strict`).
- Use a reasonable idle timeout.
- Rotate the session ID on login.
- Invalidate all sessions on password change or account deletion.

**Social login.**
- Request the minimum OAuth scopes (usually `openid email profile`).
- Don't import contacts or friends lists unless a feature needs them. Cf.
  the telemedicine Illustration to s. 6(1).

**Admin panels.**
- Use separate admin accounts with MFA and IP or VPN restrictions.
- Log every view or export of user records.

## 5. Backend and API patterns

### Purpose check middleware (Express example)
Tie every route that touches personal data to a declared purpose. Check
that there is a lawful basis before processing (s. 4). The basis is either
active consent, or a registered s. 7 legitimate use.

```js
// purposes.js — single source of truth, mirrors your data inventory
const PURPOSES = {
  account:        { basis: 'consent' },        // or s7a where user voluntarily provides
  order_delivery: { basis: 'consent' },
  marketing:      { basis: 'consent' },
  fraud_legal:    { basis: 's7d' },            // legal obligation to disclose to State, etc.
};

// middleware/requirePurpose.js
function requirePurpose(purpose) {
  return async (req, res, next) => {
    const p = PURPOSES[purpose];
    if (!p) return res.status(500).json({ error: 'unknown_purpose' });
    if (p.basis === 'consent') {
      const ok = await req.app.locals.consents.isGranted(req.user.id, purpose); // cached, short TTL
      if (!ok) return res.status(403).json({ error: 'consent_required', purpose });
    }
    if (req.user.isChild && ['marketing', 'personalised_ads', 'behavioural_analytics'].includes(purpose)) {
      return res.status(403).json({ error: 'not_permitted_for_children' });   // s. 9(3)
    }
    req.purpose = purpose;   // log it with the request for your audit trail
    next();
  };
}

app.post('/api/marketing/preferences', auth, requirePurpose('marketing'), handler);
```

### Consent API
```text
GET    /api/consents                 -> current choices for the logged-in user
POST   /api/consents                 -> grant/withdraw per purpose (append to ledger)
GET    /api/notice?lang=hi           -> current notice version in chosen language
```
On withdrawal:
1. Append a `withdrawn` event.
2. Publish a `consent.withdrawn` job or event.
3. Workers stop the related processing and call vendor APIs, e.g. remove
   the user from the email-marketing list and from ad audiences.
4. Record the vendor acknowledgements.

Keep the ledger append-only. See `assets/consent-ledger-schema.sql`.

### API security basics (s. 8(5))
- **Authorise every object access** against the current user. This prevents
  IDOR/BOLA (`/api/users/123` must check ownership). It is the most common
  cause of mass personal-data leaks in web apps.
- **Return only the fields the client needs.** Use DTOs or serializers;
  never `SELECT *` into JSON.
- **Rate-limit and paginate** list endpoints to prevent scraping.
- **Validate input** and use parameterised queries or an ORM (SQL
  injection).
- **Keep secrets in a secrets manager** or environment variables, never in
  the repo.

## 6. Encrypting personal fields

Disk or database encryption protects against stolen disks. **Field-level
encryption** protects against leaked database dumps and over-broad access.
Use it for sensitive identifiers, e.g.:
- phone numbers;
- ID numbers;
- bank details;
- health information;
- precise location.

**Node.js (AES-256-GCM).**
```js
const crypto = require('crypto');
// Key: 32 bytes from KMS / secrets manager (not hard-coded). Consider a per-user
// data key wrapped by a KMS master key so deleting the data key "crypto-shreds" backups.
function encrypt(plain, key) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ct = Buffer.concat([c.update(String(plain), 'utf8'), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), ct]).toString('base64');
}
function decrypt(b64, key) {
  const buf = Buffer.from(b64, 'base64');
  const d = crypto.createDecipheriv('aes-256-gcm', key, buf.subarray(0, 12));
  d.setAuthTag(buf.subarray(12, 28));
  return Buffer.concat([d.update(buf.subarray(28)), d.final()]).toString('utf8');
}
```

**Rails.**
```ruby
class User < ApplicationRecord
  encrypts :phone, deterministic: true   # deterministic allows lookup by phone
  encrypts :pan
end
```

**Laravel.**
```php
protected $casts = ['phone' => 'encrypted', 'pan' => 'encrypted'];
```

**Lookups on encrypted fields.** To search by email or phone without
decrypting everything, store a separate keyed hash (HMAC-SHA256 with a
secret key) of the normalised value, and index that.

## 7. User privacy features

Build a **Privacy** page in account settings. It is the user-facing side of
ss. 6, 11–14.

| Feature | Section | Implementation notes |
|---|---|---|
| Consent toggles per purpose | 6(4) | Same page as where consent was given; immediate effect |
| "Download / view my data" summary | 11 | Plain-language summary of data held, processing activities, and list of vendors/other companies it was shared with; JSON/PDF optional |
| Edit profile / correct data | 12(2) | Propagate corrections to systems that use data for decisions (s. 8(3)) |
| Delete account / erase data | 12(3), 8(7) | See flow below |
| Nominate someone | 14 | Nominee name + contact; verified on use |
| Grievance / contact DPO | 8(9)-(10), 13 | Form or email; ticket with ≤ 90-day deadline; link to Board complaint after response |

### Delete-account flow
```
User clicks "Delete account"
  → re-authenticate (password/OTP)
  → explain what is deleted and what must be retained by law (e.g. invoices for tax) and why
  → mark account pending_deletion, sign out all sessions, stop all processing
  → background job:
       1. delete/anonymise rows in app DB (keep legally required records, restricted)
       2. delete files in object storage (per-user prefix makes this one call)
       3. remove from search index, cache, email/SMS/CRM/marketing tools, analytics (vendor APIs)
       4. destroy the user's data key (crypto-shreds encrypted fields in backups)
       5. record completion + vendor acknowledgements
  → confirmation email to the user
```

**Django example of a retention purge job** (run daily). It follows
s. 8(7)–(8): erase when the purpose is no longer served. Check whether the
Rules prescribe a specific inactivity period for your class of business.

```python
# app/management/commands/purge_inactive.py
from datetime import timedelta
from django.core.management.base import BaseCommand
from django.utils import timezone
from accounts.models import User
from accounts.erasure import erase_user, send_pre_erasure_notice

INACTIVITY = timedelta(days=3 * 365)   # set per purpose / Rules
NOTICE = timedelta(hours=48)           # Rule 8 pre-erasure notice (where applicable)

class Command(BaseCommand):
    def handle(self, *args, **opts):
        now = timezone.now()
        due = User.objects.filter(last_active_at__lt=now - INACTIVITY, legal_hold_until__isnull=True)
        for u in due.filter(erasure_notice_sent_at__isnull=True):
            send_pre_erasure_notice(u); u.erasure_notice_sent_at = now; u.save(update_fields=['erasure_notice_sent_at'])
        for u in due.filter(erasure_notice_sent_at__lt=now - NOTICE):
            erase_user(u)   # same routine as delete-account
```

Only count **user-initiated** activity (login, order, message) as activity,
not your own marketing emails (s. 8(11)).

## 8. Logging, error tracking and monitoring

Rule 6 expects logs that let you detect and investigate unauthorised access,
kept for **at least one year**. But logs themselves must not become a
personal-data dump.

**Log** user ID, action, purpose, resource ID, IP (if needed for security),
timestamp and result. **Do not log** passwords, OTPs, tokens, full card
numbers, ID numbers, or request bodies.

**Node (pino) redaction.**
```js
const logger = require('pino')({
  redact: {
    paths: ['req.headers.authorization', 'req.headers.cookie', '*.password',
            '*.otp', '*.token', '*.aadhaar', '*.pan', '*.cardNumber'],
    censor: '[REDACTED]'
  }
});
```

**Error tracking (e.g., Sentry).** Turn off default PII capture and scrub
payloads.
```js
Sentry.init({
  dsn: process.env.SENTRY_DSN,
  sendDefaultPii: false,
  beforeSend(event) {
    if (event.request) { delete event.request.data; delete event.request.cookies; }
    if (event.user) event.user = { id: event.user.id };   // keep only internal id
    return event;
  }
});
```

**Security monitoring.** Alert on:
- mass exports;
- spikes in failed logins;
- admin access outside business hours;
- unusual API enumeration.

Early detection is what makes the "without delay" breach notice possible.

**CERT-In.** Separately, its 2022 directions require keeping ICT logs for
180 days within India, and reporting specified cyber incidents within 6
hours. Align retention to the longer of the two requirements.

## 9. Common integrations

**Transactional email / SMS / WhatsApp.**
- The provider is your Processor. Sign its DPA.
- Send only the needed fields.
- Set message-log retention in its dashboard.
- Suppression and unsubscribe lists must sync with your consent state.
- Marketing SMS and calls must also follow TRAI's commercial communication
  (DND) regulations.

**Payments.**
- Use the gateway's hosted checkout or tokenisation.
- **Never store card numbers.** RBI rules bar merchants from storing card
  data; use network or issuer tokens.
- Keep only the transaction reference and last 4 digits if needed.

**File uploads** (KYC documents, profile photos):
- private bucket;
- short-lived signed URLs;
- a per-user path prefix (`users/{userId}/...`) for easy erasure;
- virus scanning;
- strip EXIF metadata, since photos embed GPS location;
- lifecycle rules for retention.

**Maps and location.**
- Request precise location only when a feature needs it, and ask at that
  moment.
- Store coarse location where possible.

**Analytics.**
- Consider privacy-preserving setups: self-hosted analytics, IP truncation,
  no user IDs, aggregate only.
- These reduce what needs consent and what can leak.

**LLM or AI APIs.**
- Treat the provider as a Processor.
- Redact personal data from prompts where possible.
- Check its region and data-retention settings.
- See `ai-ml-and-agentic-systems.md`.

## 10. Children and age gating
A "child" is **anyone under 18** (s. 2(f)). This affects far more web apps
than GDPR's 13–16 thresholds.

**1. Age question.** Ask neutrally at sign-up, e.g. a date-of-birth picker
with no default suggesting an age.

**2. Under 18 → parent path.**
- Collect the parent's email or phone.
- Verify the parent is an identifiable adult (Rule 10). Options:
  - an existing verified adult account on your platform;
  - a verification token from an authorised provider, such as DigiLocker;
  - another reliable method.
- Keep the child's account restricted until verified (s. 9(1)).

**3. Flag the account** `is_child = true` and enforce the flag server-side:
- no analytics identifiers or behavioural tracking;
- no personalised or targeted ads, and no ad pixels;
- no profiling features (s. 9(3));
- review features for detrimental effects (s. 9(2)), such as public
  profiles, stranger messaging, or manipulative streaks.

**4. When the user turns 18,** ask them for their own consent.

Some classes are exempt for limited purposes under Rule 12, e.g. schools'
safety tracking or health services. Don't assume a commercial app is exempt.

## 11. Environments, testing and CI/CD
- **Don't copy production personal data** to dev, staging or local
  machines. Use seeded synthetic data, or a masking step (e.g., replace
  names, emails and phones with fakes) before any copy.
- **Restrict production database access** to a small group, via SSO, MFA
  and bastion access, with every query logged.
- **CI checks:**
  - dependency vulnerability scanning;
  - secret scanning;
  - SAST;
  - a test that personal-data endpoints require auth and ownership.
- **Privacy tests.** Add automated tests that:
  - deleting an account removes the user's rows, files and vendor
    records;
  - withdrawing a consent stops the related jobs;
  - a child account never loads marketing scripts.
- **Code review.** Add a "personal data" checkbox to the PR template: new
  fields, new vendors, new logs, new purposes. Each should be added to the
  data inventory.

## 12. CMS and no-code sites (WordPress, Shopify, Webflow, etc.)
- **Plugins and apps are Processors or third parties.** Audit each one for
  the data it collects. Form plugins store submissions, comments store IP
  addresses, and analytics plugins set cookies.
- **Use a consent plugin** that actually blocks scripts before consent, not
  just a banner.
- **Form submissions.**
  - Enable auto-deletion after a retention period.
  - Don't email full submissions to shared inboxes.
- **Keep core, themes and plugins updated.** Outdated plugins are a leading
  cause of breaches.
- **Hosted platforms.** On Shopify or Webflow, the platform is a Processor.
  Check its DPA, region, and customer-data deletion tools.

## 13. Pre-launch checklist

**Notice and consent**
- [ ] Privacy notice live: itemised data and purposes, rights, withdrawal,
      grievance contact, Board complaint route; language options (s. 5).
- [ ] Consent banner blocks non-essential scripts until consent. Reject is
      as easy as Accept, and settings are always reachable (s. 6).
- [ ] Consent choices stored server-side with version and timestamp
      (s. 6(10)).

**Data collection and security**
- [ ] Forms collect only necessary fields. Marketing opt-in is separate and
      unticked.
- [ ] Passwords hashed with Argon2id or bcrypt. OTPs hashed with expiry.
      Secure session cookies.
- [ ] Object-level authorisation on every API. No personal data in URLs or
      logs.
- [ ] Sensitive fields encrypted. Database, storage and backups in chosen
      region(s).

**Logging and vendors**
- [ ] Logs ≥ 1 year, with redaction. Error tracker scrubbed. Alerts
      configured (Rule 6).
- [ ] Vendor list with DPAs, regions and deletion methods (s. 8(2), 16).

**User rights and retention**
- [ ] Privacy settings page: consent toggles, data summary, edit,
      delete-account, nominee, grievance (ss. 11–14).
- [ ] Deletion reaches DB, files, search, caches, vendors and backups
      (crypto-shred or expiry) (s. 8(7)).
- [ ] Retention job for inactive accounts and old leads (s. 8(7)–(8)).

**Children, environments and response**
- [ ] Age gate and child restrictions, if minors could use the app (s. 9).
- [ ] Breach runbook: can list affected users and their contacts, with
      notice templates ready (s. 8(6)).
- [ ] DPO or contact published in the footer and the app (s. 8(9)).
- [ ] No production personal data in non-production environments.
