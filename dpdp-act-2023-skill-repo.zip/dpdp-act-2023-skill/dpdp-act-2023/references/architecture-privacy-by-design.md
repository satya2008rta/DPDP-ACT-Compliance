# Application Architecture for DPDP Compliance (Privacy by Design)

The Act is technology-neutral, but several provisions only work if the
system is built for them:
- proof of consent (s. 6(10));
- withdrawal and propagation to Processors (s. 6(4), 6(6));
- erasure (s. 8(7));
- breach intimation to every affected person (s. 8(6));
- rights requests (ss. 11–14);
- children's rules (s. 9).

This file turns those provisions into architecture decisions.

## Contents
1. Design principles traced to the Act
2. Reference architecture (components)
3. Key flows (sequence diagrams)
4. Data modelling patterns
5. Integration and event patterns
6. Front-end, mobile and SDK gating
7. Children and age assurance
8. Multi-tenant SaaS and Processor-side design
9. Residency and cloud region choice
10. Architecture review checklist
11. Architecture Decision Record prompts

---

## 1. Design principles traced to the Act

| Principle | Source | Architectural consequence |
|---|---|---|
| Purpose limitation | s. 5(1)(i), 6(1), 2(za) | Every personal-data field and processing activity is tagged with purpose(s). Access is checked against purpose, not just role. |
| Data minimisation | s. 6(1) "necessary for such specified purpose" | Collect per purpose. Optional fields must be separately consented, or not collected. |
| Consent as evidence | s. 6(10) burden of proof | An immutable consent ledger records the notice version, timestamp, channel, language, and the actor (self, parent, Consent Manager). |
| Symmetric withdrawal | s. 6(4) | Withdrawal is available in the same UI surface and API as grant. |
| Downstream stop | s. 6(6), 8(7)(b) | An event bus propagates withdrawals and erasures to internal services and Processors, with acknowledgement tracking. |
| Accuracy for decisions | s. 8(3) | Single source of truth for identity attributes, correction propagation, and data-quality checks before decisioning. |
| Security by default | s. 8(5), Rule 6 | Encryption, tokenisation, least privilege, logging (1 year+), backups. See `security-controls.md`. |
| Breach readiness | s. 8(6), Rule 7 | You must be able to answer, within hours, *whose* data was in the affected systems and how to contact them. This needs a data inventory plus subject-to-system lineage. |
| Storage limitation | s. 8(7)–(8), Rule 8 | Retention engine keyed on purpose, last activity, and legal holds. Pre-erasure notice (48h) workflow. |
| Rights by design | ss. 11–14 | A rights-request (DSR) orchestrator that fans out to every system of record. |
| Children | s. 9 | Age gate, verifiable parental consent service, and a "child" flag that disables tracking and targeting at the platform layer. |
| Localisation readiness | s. 16, Rule 13, sectoral laws | Region-pinnable storage and processing, and a registry of cross-border flows. |

## 2. Reference architecture

```
                ┌──────────────────────── Channels ─────────────────────────┐
                │ Web / Mobile / Call centre / Kiosk / Partner APIs          │
                └───────┬───────────────────────────────┬───────────────────┘
                        │ notice + consent UI (SDK)     │ API calls carry
                        ▼                               ▼ purpose + subject id
  ┌──────────────────────────┐   ┌──────────────────────────────────────────┐
  │ Notice & Consent Service │◄──┤ API Gateway / Policy Enforcement Point   │
  │ - notice versions (i18n) │   │ - authN/Z, purpose check (PDP call)       │
  │ - consent ledger (append)│   │ - child flag enforcement                  │
  │ - Consent Manager API    │   └───────────────┬──────────────────────────┘
  └──────────┬───────────────┘                   │
             │ events                            ▼
             ▼                    ┌──────────────────────────────────────────┐
  ┌──────────────────────┐        │ Domain services (orders, KYC, HR, CRM…)   │
  │ Privacy Event Bus    │◄──────►│ own data; subscribe to privacy events      │
  │ consent.granted      │        └───────┬──────────────────────────────────┘
  │ consent.withdrawn    │                │
  │ dsr.erase / correct  │                ▼
  │ retention.expired    │   ┌──────────────────────────────────────────────┐
  └───┬──────────────┬───┘   │ Data layer: OLTP DBs, token vault, object     │
      │              │       │ store, search, cache, DWH/lake, backups, logs │
      ▼              ▼       └──────────────────────────────────────────────┘
 ┌───────────┐ ┌──────────────────┐   ┌───────────────────┐  ┌──────────────┐
 │ Processor │ │ DSR Orchestrator │   │ Retention Engine  │  │ Data Catalog │
 │ Connector │ │ access/correct/  │   │ purpose+activity  │  │ / RoPA       │
 │ (vendors) │ │ erase/nominate   │   │ legal hold, 48h   │  │ lineage, PII │
 └───────────┘ └──────────────────┘   │ pre-erasure notice│  │ discovery    │
                                      └───────────────────┘  └──────────────┘
 ┌───────────────────────────────┐   ┌──────────────────────────────────────┐
 │ Security: KMS/HSM, SIEM (logs │──►│ Breach Response Workflow: triage →   │
 │ ≥1yr), DLP, IAM/PAM, backups  │   │ impact (catalog) → notify DP + Board │
 └───────────────────────────────┘   │ (immediate) → 72h report             │
                                     └──────────────────────────────────────┘
 ┌──────────────────────────────────────────────────────────────────────────┐
 │ Grievance desk (s.13, ≤90 days) + published DPO contact (s.8(9))          │
 └──────────────────────────────────────────────────────────────────────────┘
```

### Components

**1. Notice & Consent Service**

Owns notice templates:
- versioned;
- multilingual (English plus Eighth Schedule languages);
- itemised per Rule 3.

Owns the **consent ledger**, which is append-only. Each consent record holds:
- `subject_id`;
- `purpose_id`;
- `notice_version`;
- `status` (granted, withdrawn, expired);
- `method` (click, OTP, Consent Manager, parent);
- `language`;
- `channel`;
- `timestamp`;
- `ip` / `device`;
- `evidence_hash`.

It exposes:
- `GET /consents/{subject}?purpose=` for enforcement points;
- webhooks and APIs for registered Consent Managers.

**2. Policy Decision / Enforcement Point (PDP/PEP)**
- Every call that touches personal data declares a `purpose`.
- The PDP checks the lawful basis: consent is active, *or* a registered
  s. 7 legitimate use applies.
- It also checks the child flag and any restriction (e.g., post-withdrawal).
- Use OPA/Rego, Cedar, or your IAM's ABAC. Cache decisions briefly, with
  TTLs of seconds to minutes, so withdrawal takes effect within a
  "reasonable time".

**3. Privacy Event Bus**
- Kafka, SNS/SQS, Pub/Sub, EventBridge, or a platform event queue.
- Topics: `consent.*`, `dsr.*`, `retention.*`, `subject.corrected`,
  `breach.*`.
- Consumers must be **idempotent** and **acknowledge** completion.
- Unacknowledged events escalate. This is how you evidence "cause its Data
  Processors to cease/erase".

**4. Data Catalog / Record of Processing (RoPA)**

An inventory of:
- systems;
- data categories;
- purposes;
- lawful basis (consent or s. 7 clause);
- retention;
- Processors;
- locations and regions;
- cross-border flows.

Feed it with automated PII discovery (scanners over DBs and buckets). It is
the backbone for:
- breach impact analysis;
- s. 11(1)(b), which requires naming the Fiduciaries and Processors data was
  shared with;
- DPIAs.

**5. DSR Orchestrator.** Handles access summaries, correction and erasure,
and nominee handling:
- identity verification;
- fan-out to each system of record;
- aggregate results;
- produce a plain-language response;
- SLA timers.

**6. Retention Engine.**
- Uses per-purpose retention rules, a `last_activity_at` per subject, and
  legal-hold overrides.
- Sends the **48-hour pre-erasure notice** where Rule 8 applies.
- Emits `retention.expired` → erase.
- Preserves minimum log retention (1 year).

**7. Token Vault / Encryption Service.**
- Direct identifiers (PAN, Aadhaar, phone, email, bank account) are
  tokenised or encrypted field-level.
- Per-subject data encryption keys enable **crypto-shredding**. See
  `database-and-storage.md`.

**8. Processor Connector / Vendor Registry.**
- Lists each Processor, its contract, the data shared, its region, and its
  deletion API or manual SOP.
- Automated deletion and withdrawal calls, with evidence capture.

**9. Breach Response Workflow.**
- SIEM alert → incident.
- Catalog lookup of the affected subjects and contact channels.
- Templated notices (see `assets/breach-intimation-template.md`).
- Board submission tracker with a 72-hour clock.

**10. Grievance Desk.**
- Ticketing with SLA ≤ 90 days.
- Escalation to the DPO.
- Final response includes the route to the Board.

Right-size the design. A small company can implement several components as
modules of one service, or as configured features of an existing platform
(CRM, CMP vendor, cloud services). The capabilities are non-negotiable, but the
number of microservices is not.

## 3. Key flows

### Consent capture with proof
```mermaid
sequenceDiagram
  participant U as Data Principal
  participant App
  participant CS as Consent Service
  participant Bus as Privacy Event Bus
  App->>CS: GET notice(purposes, lang)
  CS-->>App: notice v12 (itemised data, purposes, rights, Board complaint link)
  App->>U: Show notice + per-purpose toggles (none pre-ticked)
  U->>App: Affirmative action (tap "Agree" for P1, P3)
  App->>CS: POST consent {subject, [P1,P3], notice v12, method, lang, ts, device}
  CS->>CS: Append to ledger, hash evidence
  CS->>Bus: consent.granted
```

### Withdrawal propagating to Processors
```mermaid
sequenceDiagram
  participant U as Data Principal
  participant CS as Consent Service
  participant Bus
  participant Svc as Domain services
  participant PC as Processor Connector
  participant V as Vendor (Processor)
  U->>CS: Withdraw P3 (same screen/effort as grant)
  CS->>Bus: consent.withdrawn {subject, P3}
  Bus->>Svc: stop P3 processing, purge P3-only data (unless legal retention)
  Bus->>PC: notify processors mapped to P3
  PC->>V: API/SOP: cease + erase
  V-->>PC: ack + evidence
  PC-->>Bus: processor.ack
  Note over CS: Ledger shows withdrawal ts and all acks (s.6(6), 8(7)(b))
```

### Breach
```mermaid
flowchart LR
  A[Detect: SIEM/DLP/vendor report] --> B[Triage & contain]
  B --> C[Catalog lookup: systems → subjects → contact channels]
  C --> D[Without delay: notify each affected DP + Board]
  D --> E[Investigate root cause, responsible party]
  E --> F[Detailed report to Board ≤72h or extension]
  F --> G[Remediate, lessons learned, update DPIA/controls]
```

## 4. Data modelling patterns

**Separate identity from activity.**
- Store PII in a "subject" or "profile" store keyed by an internal
  `subject_id`, which is a random UUID, not a phone or email.
- Activity, transaction and event tables reference `subject_id` or a token.
- This makes erasure and pseudonymisation tractable.

**Purpose tags at column or attribute level.**
- Keep a metadata table or catalog entry for each column: category, purpose
  set, retention rule, and whether it is a direct identifier.

**Lawful-basis column on processing records.**
- Record `basis = consent | s7a | s7b … s7i`, so you know which rights apply
  (ss. 11–12 apply only to consent and s. 7(a)).

**Last-activity timestamp.**
- Maintain `last_initiated_contact_at` per subject and purpose. This follows
  s. 8(11): the clock resets only on contact the Data Principal initiates.

**Legal hold.**
- `legal_hold_until` and `legal_basis_ref` (e.g., "PMLA record keeping")
  override erasure.

**Child flag.**
- `is_child` and `parent_subject_id`, with a verification reference.
- Enforce at the PEP so no downstream service can target or track.

**Nominee.**
- `nominee_subject_id` and `nomination_evidence` (s. 14).

**Event sourcing and immutable logs.**
- An append-only design conflicts with erasure unless personal fields are
  encrypted with per-subject keys (crypto-shredding), or events carry only
  tokens.
- Decide this **before** building. It is the single most expensive thing to
  retrofit.

See `assets/consent-ledger-schema.sql` for concrete DDL.

## 5. Integration and event patterns

**Outbox pattern.**
- Write the domain change and the privacy event in one transaction.
- Guarantees no withdrawal is "lost" between the DB and the bus.

**Idempotent consumers.**
- Erasure and withdrawal handlers must be safely re-runnable.
- Keep a `processed_events` table.

**Saga with compensations for DSRs.**
- Track per-system status, retry, then escalate to a human.

**API contracts.**
- Include `X-Purpose` and `X-Subject-Ref` headers (or claims in a JWT) on
  internal calls.
- Log them, since this is your audit trail of purpose-bound processing.

**Data sharing with other Fiduciaries.**
- Register every outbound share in the catalog.
- Required for s. 11(1)(b) access responses, and for s. 8(3) accuracy
  obligations when sharing.

**Batch ETL and CDC.**
- CDC into warehouses must also carry deletes and tombstones.
- Otherwise erasure stops at the OLTP layer.

## 6. Front-end, mobile and SDK gating
- **Load third-party SDKs only after consent** for their purpose. This
  covers analytics, ads, attribution, session replay and chat widgets.
  - Web: use a CMP or tag manager with consent mode.
  - Mobile: use a feature-flag gate at SDK initialisation.
- **Notices.** Render notices in the user's chosen language, with a language
  switcher offering English and Eighth Schedule languages.
- **Withdrawal location.** Put withdrawal on the same "Privacy" screen as
  grant, e.g., Settings → Privacy → per-purpose toggles. Withdrawal must not
  be buried in email or support tickets.
- **No dark patterns.**
  - No pre-ticked boxes.
  - No "Accept all" without an equally prominent alternative.
  - No consent bundled with terms of service when the data is not necessary.
- **Permissions.** Request mobile OS permissions (contacts, location,
  camera) only when a purpose needs them. Cf. the telemedicine Illustration
  under s. 6(1).
- **Session replay and heatmaps.** Mask input fields by default.

## 7. Children and age assurance
1. **Age gate** at sign-up. Ask for date of birth neutrally, without hinting
   at the "right" answer.
2. **Under-18 path.** Collect parent details, then verify the parent is an
   identifiable adult (Rule 10). Options:
   - existing verified adult account;
   - DigiLocker or other authorised age or identity token;
   - other reliable means.
3. **Flag the account** `is_child=true`. The PEP then blocks:
   - behavioural analytics;
   - personalised ads;
   - cross-context tracking;
   - profiling features.

   Contextual content remains allowed.
4. **Exemptions.** If a Rule 12 / Fourth Schedule exemption applies (e.g.,
   school safety tracking), scope it narrowly and document it.
5. **Age-out.** When the user turns 18, re-seek consent from the now-adult
   Data Principal, and remove the restrictions deliberately rather than
   silently.

## 8. Multi-tenant SaaS and Processor-side design
If you are a **Data Processor** (B2B SaaS, IT services, BPO), your customers
(the Fiduciaries) will require you to:
- process only on documented instructions;
- tag data per tenant, and support tenant-level export and erasure APIs;
- **propagate deletes to backups** within a defined window, or via
  crypto-shredding;
- notify the customer of breaches fast. They must notify "without delay",
  so contracts often demand notice within 6–24 hours;
- support region pinning (India regions);
- expose sub-processor lists and change notifications;
- provide audit logs to the tenant.

Offshore delivery of *non-Indian* data under contract with a foreign client
may be exempt under s. 17(1)(d). Security (s. 8(5)) still applies, and
client contracts, e.g. under GDPR, usually impose more.

## 9. Residency and cloud region choice
- The Act permits transfers unless the government blacklists a country
  (s. 16). Keep flows **inventoried and switchable**.
- **Sectoral rules may require India storage.** Examples:
  - RBI payment system data;
  - some insurance, telecom and government workloads;
  - Rule 13 localisation for SDFs.
- **India cloud regions** (verify current availability):
  - AWS: ap-south-1 (Mumbai), ap-south-2 (Hyderabad).
  - Azure: Central India (Pune), South India (Chennai), West India (Mumbai).
  - GCP: asia-south1 (Mumbai), asia-south2 (Delhi).
  - OCI: Mumbai, Hyderabad.
- **Pair two India regions for DR** so backups do not silently replicate
  abroad. Check the defaults of managed services' cross-region backup and
  replication.
- **Watch for "invisible" transfers:**
  - global CDNs caching personalised pages;
  - SaaS support staff access from abroad;
  - LLM APIs hosted outside India;
  - log shippers to foreign SIEM regions.

## 10. Architecture review checklist
- [ ] Every personal-data store is in the catalog with purpose, basis,
      retention, region and Processor.
- [ ] Each purpose maps to consent or a specific s. 7 clause, and this is
      enforced at runtime.
- [ ] The consent ledger is immutable, versioned to the notice, and
      exportable as evidence.
- [ ] Withdrawal takes the same effort as grant, reaches all consumers and
      Processors, and is acknowledged.
- [ ] Erasure reaches OLTP, replicas, caches, search indexes, the warehouse
      and lake, object storage, backups (or crypto-shred), and Processors.
- [ ] 1-year minimum processing-log retention, with logs minimised (no raw
      PII).
- [ ] The breach runbook can list affected subjects and contact channels
      within hours.
- [ ] The child path disables tracking and targeting at the platform layer.
- [ ] Rights requests have identity verification, fan-out, SLAs and
      templates.
- [ ] Non-production uses masked or synthetic data.
- [ ] Cross-border flows are listed, and the region is pinnable.
- [ ] DPO or contact is published, and the grievance SLA is ≤ 90 days.

## 11. Architecture Decision Record prompts
When writing ADRs, answer these (see `assets/adr-template.md`):
- **Erasure.** How does this component erase one subject's data? How long
  does it take? What evidence is produced?
- **Withdrawal.** How does it learn about withdrawal of a purpose?
- **Breach impact.** What personal data does it hold, and could we
  enumerate affected subjects after a breach?
- **Location.** Where is data stored and processed, including backups, logs
  and vendor support access?
- **Minimisation.** What is the minimal data for its purpose?
- **Children.** How are children's accounts treated?
