# AI, ML, LLM and Agentic Systems under DPDP

The Act has no AI-specific chapter, but every stage of an AI system that
touches personal data is "processing" (s. 2(x)): collection, labelling,
training, embedding, inference, logging, and agent actions. The same rules
apply throughout.

## Lifecycle mapping

| Stage | DPDP questions | Design answer |
|---|---|---|
| **Data sourcing** | Basis? Was the data collected for this purpose? Is scraped "public" data really exempt? | Training on customer data is usually a **new purpose**. It needs consent, or anonymisation first. The s. 3(c)(ii) public-data carve-out covers only data made public *by the Data Principal* or under a legal duty. Document the provenance of scraped data and filter out data that is not covered. |
| **Training / fine-tuning** | Minimisation; erasure once a model has learned the data | Prefer anonymised or aggregated data. Keep a dataset→model lineage record, i.e. which subjects' data is in which training set. On erasure, delete from datasets and exclude from future training runs. Assess whether retraining or unlearning is proportionate. Document the reasoning. |
| **Embeddings / RAG** | Embeddings are derived personal data | Store `subject_id` and purpose metadata with vectors. Delete vectors on erasure. Filter retrieval by the requester's authorisation and purpose, so RAG does not surface other people's data. Store in India regions if required. |
| **Inference with third-party LLM APIs** | The API provider is a Data Processor; cross-border transfer | Have a valid contract (s. 8(2)) with zero or limited retention and no training on your data. Check the region, redact or tokenise PII before prompts where possible, and log the prompts that contain PII. |
| **Automated decisions** (credit, hiring, fraud, pricing) | Accuracy (s. 8(3)); SDF algorithmic due diligence (Rule 13) | Validate data quality. Test for bias and error. Keep human review for significant decisions (a good practice, though not an explicit right under the Act). Explain decisions in grievance responses. |
| **Children** | s. 9(3): no tracking, monitoring or targeting | Do not profile under-18 users for personalisation or ads. Tutoring AI should use session context, not behavioural profiles. |
| **Logs & transcripts** | Retention, security | Chatbot transcripts are personal data. Set retention, mask sensitive fields, and give them to the DSR orchestrator. |

## Agentic AI (tool-using agents)
Agents that read from and write to business systems (databases, CRM, email, internal APIs)
act as part of the Fiduciary's processing. Design for:

**Purpose-scoped tool permissions.**
- Scope each agent or skill to purposes.
- Enforce purpose checks at the tool or API layer through the PEP, not only
  in the prompt.

**Least-privilege identities.**
- Give the agent its own service identity.
- Do not reuse admin credentials.
- Use row and field-level access matching the human role it assists.

**Guardrails on data egress.**
- Block agents from sending personal data to external tools or domains that
  are not registered Processors.
- Apply DLP to outputs.

**Consent-awareness.**
- Before acting, e.g. sending marketing or enriching a lead, the agent
  should query consent status.
- Withdrawal must stop agent actions too.

**Audit trail.**
- Log agent actions with subject reference, purpose, tool and outcome, for
  1 year or longer.
- This supports s. 6(10) proof of consent and breach forensics.

**Human-in-the-loop** for high-impact actions:
- erasure;
- bulk exports;
- decisions affecting a Data Principal.

**Prompt-injection defence.**
- Treat retrieved content as data, not instructions.
- Isolate tools.
- An injected instruction to exfiltrate PII becomes a personal data breach
  that must be notified.

## B2B lead generation and enrichment (common use case)
- **Business contact data about identifiable individuals is personal data.**
  This includes name, work email, phone and LinkedIn profile. There is no
  B2B exemption.
- **Buying enriched contact lists.** The vendor may be a separate Data
  Fiduciary. Get assurance of its lawful basis, since your own basis for
  outreach is typically consent.
- **"Publicly available" data.** Is it covered by s. 3(c)(ii) only if the
  person *herself* made it public? Profiles people publish themselves are
  arguable. Aggregator-compiled data is weaker. Treat this as a legal risk
  and take counsel's view.
- **Every outreach message** should provide:
  - an easy opt-out, which acts as consent withdrawal (s. 6(4));
  - a contact for questions (s. 8(9));
  - a route to grievance redressal (s. 13).
- **Maintain a suppression list**, and honour it across tools and agents.

## SDF-specific (Rule 13)
If notified as an SDF, you must carry out due diligence to verify that
algorithmic software, including AI models used for hosting, display, upload,
modification, publishing, transmission, storage, updating or sharing of
personal data, is not likely to pose a risk to Data Principals' rights.
Build model risk management covering:
- inventory;
- risk tiering;
- testing;
- monitoring;
- a documented annual review feeding the DPIA.
