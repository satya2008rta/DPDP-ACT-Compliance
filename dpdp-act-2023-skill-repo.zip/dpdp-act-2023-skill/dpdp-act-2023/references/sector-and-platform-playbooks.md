# Sector and Platform Playbooks

Use these as starting points. Always check sector regulators' rules, which
continue to apply under s. 16(2) and s. 38(1). Where they are stricter, they
usually win in practice.

## Contents
1. SaaS products & third-party services in a web stack
2. CRM, marketing & lead generation
3. HR & employee data
4. E-commerce & consumer apps
5. BFSI (banks, NBFCs, fintech, insurance)
6. Healthcare & health-tech
7. Ed-tech & anything with children
8. IT services, BPO & GCCs
9. Government & public sector

---

## 1. SaaS products & third-party services in a web stack

**Roles.**
- **Building a SaaS product for businesses:** you are usually a **Data
  Processor** for your customers' end-user data, and a **Data Fiduciary**
  for your own customers' account and billing data.
- **Using third-party services:** each one you plug in is your **Processor**
  and needs a valid contract (s. 8(2)). Typical examples:
  - hosting;
  - email/SMS/WhatsApp APIs;
  - payment gateways;
  - analytics;
  - error tracking;
  - support chat;
  - file storage;
  - LLM APIs.

  The provider's standard DPA is often sufficient. Check it against
  `assets/processor-contract-clauses.md`.

**Third-party service checklist.** For each vendor in the stack, record:
- what personal data it receives, including anything captured automatically
  (IP, device, session replay, error payloads);
- the purpose, and whether it needs consent before loading, e.g. analytics
  or marketing pixels;
- its hosting region and any cross-border transfer (s. 16);
- how to delete one user's data from it (API, dashboard or support ticket);
- its breach notification commitment.

**Hidden copies of personal data in a typical web app:**
- error trackers (request bodies, user context);
- application and access logs;
- email/SMS provider message logs;
- support inbox and chat transcripts;
- CDN and reverse-proxy logs;
- database backups;
- staging databases seeded from production;
- CSV exports on laptops.

Include each of these in erasure and retention design.

## 2. CRM, marketing & lead generation

**Consent and suppression.**
- Keep consent per channel and purpose (email, SMS, WhatsApp, calls).
- Sync suppression across the CRM, marketing automation, dialers and agents.

**TRAI TCCCPR.**
- For telecom messages and calls, the DND and commercial communication
  regulations apply in addition.

**Purchased or enriched lists.**
- Get vendor assurances.
- Record the source per contact, since this is needed for s. 11(1)(b).

**Tracking.**
- Web tracking pixels and cookies may load only after consent. See the
  architecture §6.

**Erasure.**
- Erasure must reach ad platforms (customer-match audiences) and data
  enrichment vendors.

## 3. HR & employee data

**Lawful basis.**
- s. 7(i) covers employment purposes and protecting the employer from loss
  or liability.
- It is broad, but keep processing **proportionate** and document it.
- Use consent for anything non-essential: wellness apps, social features,
  voluntary surveys.

**Candidates are not yet employees.**
- For recruitment data, consider s. 7(a) or consent.
- Define retention for rejected candidates.

**Monitoring.**
- DLP and endpoint monitoring can fit s. 7(i) (corporate espionage, trade
  secrets).
- Give notice anyway as good practice, and avoid excessive monitoring.

**Former employees.**
- Retain only as long as labour, tax and PF laws require.
- Erase the rest.

**Rights.**
- ss. 11–12 do not attach to s. 7(i) processing.
- An internal policy may still grant access as good practice.

## 4. E-commerce & consumer apps
- **Three-year inactivity erasure** for large platforms under Rule 8. Build
  the 48-hour pre-erasure notice and `last_activity` tracking.
- **Withdrawal.** Must not break fulfilment of already-paid orders (s. 6(5)
  Illustration).
- **Marketplace sellers** may be separate Fiduciaries. Define roles and data
  sharing in seller terms.
- **Consumer Protection (E-Commerce) Rules** and CCPA dark-pattern
  guidelines (2023) intersect with consent UX.

## 5. BFSI
**Overlapping requirements:**
- RBI payment data storage (system data stored only in India);
- RBI IT/outsourcing/cyber directions;
- KYC/PMLA retention;
- the Credit Information Companies Act;
- SEBI CSCRF;
- IRDAI information and cyber security guidelines.

**DPDP-specific points:**
- s. 7(d)–(e) (legal disclosures and orders);
- s. 17(1)(f) (loan-default asset tracing);
- s. 8(3) accuracy for credit decisions;
- consent for cross-sell;
- **Account Aggregator** consent artefacts. The AA framework's consent model
  is a useful blueprint for consent managers.

## 6. Healthcare & health-tech

**Health data isn't a special category, but:**
- sensitivity raises penalty exposure (s. 33(2)(b));
- it is a factor in SDF designation.

**Lawful bases:**
- medical emergency, s. 7(f);
- epidemic, s. 7(g).

**Children.**
- Rule 12 exemptions exist for healthcare professionals and clinical
  establishments, limited to health services.

**Other frameworks:**
- ABDM health data management policy;
- Telemedicine Practice Guidelines;
- the Clinical Establishments Act.

**Minimisation.**
- The telemedicine Illustration shows the principle: contact lists are not
  necessary.

## 7. Ed-tech & anything used by under-18s
- **Children's rules apply** (s. 9):
  - verifiable parental consent;
  - no tracking or behavioural monitoring;
  - no targeted ads;
  - no detrimental processing.
- **Educational-institution exemptions** under Rule 12 are narrow:
  educational activities and safety. Commercial ed-tech platforms should
  not assume they are covered.
- **Architecture.** See the child flag and PEP pattern in
  `architecture-privacy-by-design.md` §7.

## 8. IT services, BPO & GCCs
- **s. 17(1)(d)** exempts most of Chapters II–III for processing non-Indian
  residents' data under a contract with a foreign entity. Security
  (s. 8(5)) and accountability still apply.
- **Data of Indian residents is fully covered.** This includes Indian
  employees and domestic clients' customers.
- **As a Processor**, expect flow-down clauses from Indian clients, and
  build deletion and breach-notice capability.

## 9. Government & public sector
- **s. 7(b)–(c)** provide wide bases for the State.
- **s. 17(4) removes:**
  - erasure (s. 8(7));
  - erasure on request (s. 12(3));
  - correction, for non-decisional processing.
- **s. 17(2)(a)** allows notified agencies to be fully exempt.
- **Security and breach obligations still apply** unless the agency is
  exempt.
- **Vendors building government systems** must still meet Processor
  expectations.
