# Board, Enforcement, Appeals, Penalties and Miscellaneous (ss. 18–44 + Schedule)

## Contents
1. Data Protection Board of India (ss. 18–26)
2. Powers, functions and procedure (ss. 27–28)
3. Appeals and ADR (ss. 29–32)
4. Penalties (ss. 33–34 + Schedule)
5. Miscellaneous (ss. 35–44)

---

## 1. Data Protection Board of India — Chapter V

**s. 18: Establishment**
- The Board is established from a notified date.
- It is a body corporate with perpetual succession and a common seal, and
  can sue and be sued.
- Its headquarters is notified by the government.

**s. 19: Composition**
- A Chairperson plus the number of Members the government notifies.
- The Central Government appoints them in the prescribed manner.
- Members must be persons of ability, integrity and standing, with expertise
  in areas such as data governance, consumer protection, dispute resolution,
  ICT, the digital economy, law, or techno-regulation.
- **At least one must be a legal expert.**

**s. 20: Terms**
- Salary and terms are as prescribed and may not be varied to a member's
  disadvantage after appointment.
- The term is **two years**, and members are eligible for reappointment.

**s. 21: Disqualification**
A person is disqualified who has:
- been adjudged insolvent;
- been convicted of an offence involving moral turpitude;
- become physically or mentally incapable;
- acquired a prejudicial financial or other interest; or
- abused her position.

A member cannot be removed without an opportunity of being heard.

**s. 22: Resignation and vacancy**
- A resignation takes effect at the earliest of:
  - government permission;
  - three months after notice;
  - a successor taking office;
  - term expiry.
- Vacancies are filled by fresh appointment.
- **Cooling-off period:** for **one year** after leaving office, a member
  may take no employment without government approval. She must also
  disclose any later employment with a Fiduciary against whom she handled
  proceedings.

**s. 23: Proceedings**
- Meetings may be held by digital means.
- Acts are not invalid merely because of a vacancy, a defect in
  appointment, or a procedural irregularity not affecting the merits.
- The senior-most Member acts for an absent Chairperson.

**s. 24: Staff.** The Board appoints officers and employees with prior
government approval.

**s. 25: Public servants.** Members and staff are public servants under
IPC s. 21.

**s. 26: Powers of the Chairperson**
- General superintendence.
- Authorising officers to scrutinise intimations and complaints.
- Allocating proceedings to individual Members or groups.

## 2. Powers, functions and procedure — Chapter VI

**s. 27(1): Functions.** The Board acts on:
- **(a) a breach intimation** under s. 8(6). It can direct urgent remedial
  or mitigation measures, inquire, and impose a penalty;
- **(b) a complaint** by a Data Principal (about a breach or a Fiduciary's
  non-compliance), a **reference** from the Central or a State Government,
  or a **court direction**. It inquires and may impose a penalty;
- **(c) a complaint against a Consent Manager**;
- **(d) an intimation** of breach of a Consent Manager's registration
  conditions;
- **(e) a government reference** about an **intermediary** breaching
  s. 37(2) (blocking directions).

**s. 27(2)–(3): Directions.** The Board may issue binding directions after
a hearing, with recorded reasons. It may modify, suspend, withdraw or cancel
them on representation or on government reference.

**s. 28: Procedure**
- **Digital by design.** The Board is independent and functions as a
  **digital office**, using techno-legal measures (28(1)).
- **Stages:**
  - determine whether there are sufficient grounds (28(3));
  - if insufficient, close with reasons (28(4));
  - if sufficient, inquire (28(5)).
- **Natural justice.** The inquiry follows the principles of natural
  justice, with reasons recorded (28(6)).
- **Civil-court powers (28(7)).** Under the CPC 1908, the Board can:
  - summon and examine on oath;
  - receive evidence on affidavit and require discovery;
  - inspect any data, books or documents;
  - exercise other prescribed powers.
- **No disruptive seizures.** The Board may not block access to premises or
  seize equipment in a way that adversely affects day-to-day functioning
  (28(8)).
- **Police assistance.** The Board may requisition police or government
  officers (28(9)).
- **Interim orders.** May be issued after a hearing (28(10)).
- **Outcome.** After a hearing, the Board closes the matter or proceeds to
  a penalty under s. 33 (28(11)).
- **False or frivolous complaints.** The Board may issue a warning or impose
  costs on the complainant (28(12)).

## 3. Appeals and ADR — Chapter VII

**s. 29: Appeal to TDSAT**
- **Who and when:** any person aggrieved by a Board order or direction may
  appeal within **60 days**. The prescribed form and fee apply.
- **Delay:** the tribunal may condone delay for sufficient cause.
- **Orders:** it may confirm, modify or set aside the Board's order.
- **Speed:** it should endeavour to dispose of the appeal within **six
  months**, and must record reasons if it does not.
- **Mode:** the tribunal functions as a digital office.
- **Further appeal:** lies under TRAI Act s. 18, i.e., to the **Supreme
  Court**.

**s. 30: Execution.** TDSAT orders are executable as civil court decrees.
The tribunal may transmit them to a local civil court for execution.

**s. 31: Mediation.** The Board may direct the parties to attempt
mediation, using a mediator they agree on or one provided by law.

**s. 32: Voluntary undertaking**
- The Board may accept an undertaking at any stage of a s. 28 proceeding.
- The undertaking may commit the person to act, or to refrain from acting,
  within a set time, and may include publicising it.
- Terms may be varied with consent.
- Acceptance **bars proceedings** on the matters it covers.
- **Breach** of an undertaking is deemed a breach of the Act and leads to
  a s. 33 penalty.

## 4. Penalties — Chapter VIII + Schedule

**s. 33(1).** If, after inquiry, the Board finds a breach **significant**,
it may impose a monetary penalty per the Schedule, after a hearing.

**s. 33(2): Factors the Board must consider**
- (a) the nature, gravity and duration of the breach;
- (b) the type and nature of personal data affected;
- (c) whether the breach is repetitive;
- (d) any gain realised or loss avoided;
- (e) mitigation action taken, and its timeliness and effectiveness;
- (f) whether the penalty is proportionate and effective as a deterrent;
- (g) the likely impact of the penalty on the person.

**s. 34.** Penalties are credited to the **Consolidated Fund of India**.
There is **no compensation to victims** under this Act.

### THE SCHEDULE (s. 33(1))

| # | Breach | Maximum penalty |
|---|---|---|
| 1 | Failure to take **reasonable security safeguards** to prevent a personal data breach, s. 8(5) | **₹250 crore** |
| 2 | Failure to notify the **Board or affected Data Principals** of a personal data breach, s. 8(6) | **₹200 crore** |
| 3 | Breach of **additional obligations for children**, s. 9 | **₹200 crore** |
| 4 | Breach of **additional obligations of an SDF**, s. 10 | **₹150 crore** |
| 5 | Breach of **duties of Data Principal**, s. 15 | **₹10,000** |
| 6 | Breach of a **voluntary undertaking**, s. 32 | Up to the extent applicable to the breach for which the s. 28 proceedings were instituted |
| 7 | Breach of **any other provision** of the Act or Rules | **₹50 crore** |

(1 crore = 10 million. ₹250 crore ≈ ₹2.5 billion.)

**s. 42.** The government may amend the Schedule by notification, but may
not raise any penalty to **more than twice** its original amount.

**Exposure note.** A single incident can engage several items, for example
a security failure (item 1) plus failure to notify (item 2). The Act does
not say how penalties aggregate, so treat stacking as a risk.

## 5. Miscellaneous — Chapter IX

**s. 35: Good faith.** No suit or prosecution lies against the government,
the Board or its members and staff for acts done in good faith.

**s. 36: Information.** The government may require the Board, any Data
Fiduciary or any intermediary to furnish information.

**s. 37: Blocking**
- **Trigger:** on a written reference from the Board that (a) it has
  penalised a Fiduciary in **two or more instances**, and (b) it advises
  blocking in the public interest.
- **Power:** after a hearing, the government may order any government agency
  or **intermediary** to block public access to the information or computer
  resource that enables the Fiduciary to offer goods or services in India.
- **Compliance:** intermediaries must comply (37(2)).
- **Definitions:** terms follow the IT Act 2000.

**s. 38: Other laws.** The Act supplements other laws and prevails on
conflict. See `scope-exemptions-transfers.md`.

**s. 39: Bar of jurisdiction.** No civil court has jurisdiction over matters
the Board is empowered to decide, and no injunction is available against
action under the Act.

**s. 40: Rule-making.**
- The government may make Rules, after previous publication.
- s. 40(2)(a)–(z) lists the matters Rules may cover. These are every "as
  may be prescribed" item: notice manner, Consent Manager registration,
  breach intimation, retention periods, verifiable parental consent, DPIA
  contents, request procedures, the grievance timeline, the nomination
  manner, research standards, Board appointments, and appeal procedure.

**s. 41: Parliamentary scrutiny.** Rules and notifications under s. 16 and
s. 42 are laid before Parliament for 30 days. Parliament may modify or
annul them.

**s. 42: Schedule amendment.** Allowed, with a cap of 2× the original
penalty.

**s. 43: Removal of difficulties.** The government may issue orders to
remove difficulties, but only within **three years** of commencement.

**s. 44: Amendments to other Acts**
- **TRAI Act s. 14(c):** TDSAT becomes the appellate tribunal for the IT
  Act, the AERA Act, and **the DPDP Act**.
- **IT Act 2000:**
  - **s. 43A is omitted**, removing compensation for failure to protect
    sensitive personal data. The SPDI Rules 2011 fall away with it.
  - s. 81 proviso: adds the DPDP Act alongside the Patents Act.
  - s. 87(2)(ob) is omitted.
- **RTI Act 2005 s. 8(1)(j)** is replaced with an exemption for
  "information which relates to personal information". The earlier
  public-interest override within that clause is removed.
