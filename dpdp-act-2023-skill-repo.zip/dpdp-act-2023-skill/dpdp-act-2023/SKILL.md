---
name: dpdp-act-2023
description: India's Digital Personal Data Protection Act, 2023 (DPDP Act / DPDPA) and DPDP Rules 2025 — legal guidance plus hands-on engineering guidance for building compliant websites, web apps, SaaS and mobile backends. Use this skill whenever the user asks about Indian data protection or privacy law, or is designing, building or reviewing any application that collects personal data of people in India — signup/login flows, forms, cookie or consent banners, privacy notices, analytics and tracking scripts, choosing a database or hosting region, encrypting user data, account deletion, data retention, logging, breach response, children/age gating, vendor/API integrations, AI/LLM features, gap assessments, checklists, penalties, or DPDP vs GDPR — even if the user never mentions the Act by name.
---

# DPDP Act 2023: Law + Web Application Engineering

This skill makes Claude a practical guide to India's Digital Personal Data
Protection Act, 2023 (No. 22 of 2023, assented 11 Aug 2023) and its Rules.
It works at two levels:

1. **Law.** What the Act requires, with exact section citations.
2. **Engineering.** How to build it into real web applications:
   - architecture;
   - database and hosting choices;
   - frontend consent and tracking;
   - auth;
   - APIs;
   - encryption;
   - deletion;
   - logging;
   - vendors;
   - AI features.

Aim for answers a developer can implement and a privacy lead can defend.

## Status of the law (verify dates before relying on them)
- **Act:** in force on dates the government notifies (s. 1(2)).
- **DPDP Rules, 2025:** notified 13 Nov 2025, and phased in:
  - Board provisions: immediately.
  - Consent Managers: ~13 Nov 2026.
  - Most obligations (notice, security, breach, retention, children,
    rights, SDF): ~13 May 2027.
- Dates and figures can change by notification. When the answer depends on
  what is in force today, or on an exact number, say so and suggest checking
  meity.gov.in, or search the web if you can.

See `references/dpdp-rules-2025.md`.

## Step 1: Work out what kind of question it is

| Question type | Go to |
|---|---|
| Building or reviewing a website / web app / API / mobile backend | `references/web-development.md` (start here for most dev questions) |
| System architecture, microservices, event flows, consent service design | `references/architecture-privacy-by-design.md` |
| Which database / storage / warehouse; schema; deletion across backups | `references/database-and-storage.md` + `assets/consent-ledger-schema.sql` |
| Security controls, "reasonable safeguards", logging, breach runbook | `references/security-controls.md` |
| AI / LLM / RAG / agents / lead enrichment | `references/ai-ml-and-agentic-systems.md` |
| Industry context (SaaS, e-commerce, fintech, health, ed-tech, HR, BPO, govt) | `references/sector-and-platform-playbooks.md` |
| Programme plan, roadmap, RACI | `references/implementation-roadmap.md` |
| Meaning of a legal term | `references/definitions.md` |
| Does the Act apply? exemptions? cross-border? | `references/scope-exemptions-transfers.md` |
| Notice, consent, legitimate uses, general duties, children, SDF | `references/data-fiduciary-obligations.md` |
| User rights and duties | `references/data-principal-rights-duties.md` |
| Board, appeals, penalties, blocking, rule-making, IT/RTI Act changes | `references/board-enforcement-penalties.md` |
| Compare with GDPR | `references/dpdp-vs-gdpr.md` |
| Which section covers X | `references/section-index.md` |

Read only what the question needs. For a design review, read
`web-development.md` plus whichever of architecture, database or security
applies.

## Step 2: Legal analysis (always, briefly)
1. **Applicability (s. 3, 17).** Check each condition:
   - Is the data digital, or digitised later?
   - Is the processing in India, or does it offer goods or services to
     people in India?
   - Is it outside the carve-outs (personal/domestic use; data made public
     by the person herself or under a legal duty)?
   - Does any s. 17 exemption apply?
2. **Role.**
   - **Data Fiduciary:** decides the purpose and means.
   - **Data Processor:** acts on a Fiduciary's behalf. It has no direct
     statutory duties; the Fiduciary stays liable (s. 8(1)), and duties
     reach the Processor by contract (s. 8(2)).
   - Also check whether the user is a **Significant Data Fiduciary** or a
     **Consent Manager**.
3. **Lawful basis (s. 4).** Consent (s. 6) or one of the closed list of
   legitimate uses (s. 7). There is **no** general "legitimate interests"
   basis.
4. **Obligations.** Map them and cite the sections, e.g. `s. 8(6)`. Use the
   Act's Illustrations where they fit.
5. **Prescribed details.** Flag anything "as may be prescribed", and give
   the Rules position.

## Step 3: Engineering answer (for any build/design question)
Translate each obligation into concrete design: components, data model,
code, configuration, vendor settings and tests. Check the design against
the **five capabilities every app needs**:
1. **Notice and per-purpose consent with evidence** (s. 5, 6, 6(10)).
2. **Easy withdrawal** that also stops downstream processing and vendors
   (s. 6(4), 6(6)).
3. **Find, export, correct and delete one user's data everywhere:**
   DB, files, search, caches, warehouse, vendors, and backups via
   crypto-shredding or expiry (s. 8(7), 11, 12).
4. **Reasonable security with logs of at least one year** (s. 8(5),
   Rule 6).
5. **After a breach, identify every affected user and notify them and the
   Board** (s. 8(6), Rule 7).

When recommending technology, give a default choice with reasons plus the
DPDP-relevant watch-outs. Don't list every option. Examples:
- "PostgreSQL in an India region, with app-layer field encryption and a
  per-user data key".
- "Load analytics only after consent via a CMP or a gated script".

## Step 4: Deliverables
Use the templates in `assets/`, filled in with the user's facts:

| Asset | Use for |
|---|---|
| `privacy-notice-template.md` | s. 5 / Rule 3 notice |
| `consent-request-template.md` | Consent UI copy + checklist |
| `breach-intimation-template.md` | Two-stage breach notices |
| `grievance-response-template.md` | Rights / grievance replies |
| `processor-contract-clauses.md` | Vendor DPA clauses (s. 8(2)) |
| `gap-assessment-template.md` | Compliance gap table |
| `dpia-template.md` | Impact assessment |
| `ropa-template.csv` | Data inventory |
| `adr-template.md` | Architecture decision with DPDP prompts |
| `consent-ledger-schema.sql` | PostgreSQL schema for users, consent, rights, vendor acks |

Scripts (Python 3, standard library only):
- `python scripts/dpdp_checklist.py --web --processors [--children --ai --sdf --cross-border --engineering]`
  builds a tailored checklist. `--role processor` gives a SaaS vendor view.
- `python scripts/datastore_assessment.py inventory.json [--india-only]`
  flags gaps in each database or store. See
  `assets/datastore-inventory-example.json` for the input format.
- `python scripts/penalty_lookup.py [keyword|all] [--factors]` shows the
  Schedule penalty caps and the s. 33(2) factors.

## Output conventions
- **Quick question:** give a direct answer in a few paragraphs, with
  section citations inline.
- **Design or code review:**
  - list findings by severity;
  - give the section each finding relates to;
  - give the concrete fix, with code or config where useful.
- **Code:** production-quality and minimal. Keep secrets out of code. Use
  the user's stack if known.
- **Close with a one-line caveat:** general guidance, not legal advice. No
  long hedging.

## Traps to avoid
- **Child = under 18** (s. 2(f)).
  - Verifiable parental consent is required.
  - No tracking, behavioural monitoring or targeted ads for children
    (s. 9(3)).
  - This affects most consumer web apps.
- **No sensitive-data tier.** All personal data is protected equally.
  Sensitivity affects penalty size (s. 33(2)(b)) and SDF designation.
- **Breach notice is unconditional.** Every personal data breach goes to the
  Board **and** each affected person (s. 8(6)). There is no "low risk"
  exception. Ransomware and loss of availability count too.
- **Withdrawal must be as easy as consent** (s. 6(4)). Rejecting cookies
  must be as easy as accepting them.
- **Consent covers only necessary data.** Bundled extra permissions are
  ineffective (s. 6(1)). Waivers of rights are void (s. 6(2)).
- **Rights are limited to:**
  - access to a summary (s. 11);
  - correction, completion, updating and erasure (s. 12);
  - grievance redressal (s. 13);
  - nomination (s. 14).

  There is no portability or objection right. Rights attach to consent and
  s. 7(a) processing only.
- **Penalties are caps.** They apply after an inquiry finds a significant
  breach:
  - up to ₹250 cr (security safeguards);
  - up to ₹200 cr (breach notification, children);
  - up to ₹150 cr (SDF duties);
  - up to ₹50 cr (anything else);
  - up to ₹10,000 (user duties).

  There is no compensation to individuals; IT Act s. 43A was omitted.
- **Cross-border transfer** is allowed unless a country is notified as
  restricted (s. 16). Stricter sectoral rules still apply, e.g. RBI payment
  data localisation.
- **Grievance before the Board.** Users must use the company's grievance
  process first (s. 13(3)). Appeals go to TDSAT within 60 days (s. 29). Civil
  courts are barred (s. 39).
- **"Publicly available" data** is exempt only if made public by the person
  herself or under a legal duty (s. 3(c)(ii)). Scraped third-party
  compilations are not automatically exempt.

## Example
**User:** "I'm building a Next.js + Node e-commerce site for Indian
customers. What do I need for DPDP?"

**Good answer shape:**
1. **Applicability:** yes, and you are the Data Fiduciary.
2. **Stack:**
   - PostgreSQL in the Mumbai or Hyderabad region;
   - random user IDs;
   - encrypted phone and address fields;
   - payment through gateway tokenisation, never storing cards.
3. **Frontend:**
   - itemised notice;
   - consent banner that gates GA and Meta Pixel;
   - separate marketing opt-in;
   - footer privacy settings.
4. **Backend:**
   - purpose middleware;
   - consent API and ledger;
   - object-level authorisation;
   - pino redaction;
   - Sentry scrubbing;
   - logs kept ≥1 year.
5. **Privacy settings page:**
   - data summary;
   - edit;
   - delete account (a job that reaches DB, S3, email tool and ad
     audiences, then crypto-shreds);
   - nominee;
   - grievance with a 90-day SLA.
6. **Retention:**
   - purge inactive accounts, with a 48h notice if Rule 8's threshold
     applies;
   - keep invoices for tax law.
7. **Breach runbook:** templates ready to notify the Board and customers.
8. **Children:** if under-18s may buy, add an age gate and suppress pixels
   for them.
9. **Vendors:** DPAs with the email/SMS, hosting and analytics providers.

Offer
`dpdp_checklist.py --web --processors --engineering` for the full list.
