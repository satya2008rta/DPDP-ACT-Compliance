# DPDP Act 2023 Skill — Indian Data Protection for Web Developers

An **Agent Skill** that teaches Claude (and other AI coding agents) India's
**Digital Personal Data Protection Act, 2023** and **DPDP Rules, 2025**, and
how to build compliant websites, web apps, APIs and SaaS products.

It answers both kinds of question:
- **Legal:** "Do we need parental consent?" "What's the penalty for a late
  breach notice?" "Does the Act apply to our offshore team?"
- **Engineering:** "Which database and region should we use?" "How do I
  gate Google Analytics until consent?" "How do I delete a user from
  backups?" "Review my signup flow."

## What's inside

```
dpdp-act-2023/                      ← the skill (copy this folder)
├── SKILL.md                        ← entry point: workflow, routing, traps
├── references/
│   ├── web-development.md          ← forms, cookies, consent banner, auth, APIs, encryption, deletion, logging (with code)
│   ├── architecture-privacy-by-design.md  ← reference architecture, flows, data modelling
│   ├── database-and-storage.md     ← DB selection criteria, engine notes, erasure across backups/warehouses
│   ├── security-controls.md        ← Rule 6 "reasonable safeguards", breach timeline, CERT-In
│   ├── ai-ml-and-agentic-systems.md← LLMs, RAG, embeddings, agents, lead enrichment
│   ├── sector-and-platform-playbooks.md ← SaaS, e-commerce, fintech, health, ed-tech, HR, BPO, govt
│   ├── implementation-roadmap.md   ← phased programme to May 2027, RACI
│   ├── definitions.md              ← s. 2
│   ├── scope-exemptions-transfers.md ← ss. 1, 3, 16, 17, 38
│   ├── data-fiduciary-obligations.md ← ss. 4–10
│   ├── data-principal-rights-duties.md ← ss. 11–15
│   ├── board-enforcement-penalties.md ← ss. 18–44 + Schedule
│   ├── dpdp-rules-2025.md          ← Rules summary & phased dates
│   ├── dpdp-vs-gdpr.md
│   └── section-index.md            ← all 44 sections → file
├── assets/                          ← templates: notice, consent UI, breach notices, grievance reply,
│                                      DPA clauses, gap assessment, DPIA, RoPA CSV, ADR, Postgres schema
└── scripts/                         ← Python 3, no dependencies
    ├── dpdp_checklist.py           ← tailored checklist (--web --children --ai --sdf ...)
    ├── datastore_assessment.py     ← flags DB/storage gaps from a JSON inventory
    └── penalty_lookup.py           ← penalty Schedule + s. 33(2) factors
```

## Install

### Claude.ai / Claude desktop app
1. Download `dpdp-act-2023.skill` from Releases, or zip the `dpdp-act-2023/`
   folder.
2. Go to **Settings → Capabilities → Skills → Upload skill**. Menu names may
   differ slightly by plan.
3. Ask anything about DPDP or building a compliant web app. The skill loads
   automatically.

### Claude Code
Personal skill:
```bash
git clone https://github.com/<you>/dpdp-act-2023-skill.git
cp -r dpdp-act-2023-skill/dpdp-act-2023 ~/.claude/skills/
```
Project skill, shared with your team via the repo:
```bash
mkdir -p .claude/skills && cp -r dpdp-act-2023 .claude/skills/
```
As a plugin marketplace:
```
/plugin marketplace add <you>/dpdp-act-2023-skill
/plugin install dpdp-skills@dpdp-act-2023-skill
```

### Claude API (Agent Skills)
Upload the folder as a custom skill through the Skills API and reference it
in your requests. See Anthropic's Agent Skills documentation.

### Other agents (Codex, Cursor, Copilot, Gemini CLI, etc.)
`SKILL.md` is plain Markdown with YAML front-matter, so it is portable:
- **Tools that support the Agent Skills folder format:** point them at
  `dpdp-act-2023/`.
- **Tools that read `AGENTS.md` or rules files:** use the provided
  `AGENTS.md`, which points the agent to the skill. You can also copy
  `SKILL.md` into `.cursor/rules/`, `.github/copilot-instructions.md`, or
  similar.
- **Plain chat / custom GPTs / system prompts:** paste `SKILL.md`, and
  attach the relevant `references/*.md` files as knowledge.

## Quick use of the scripts
```bash
cd dpdp-act-2023
python scripts/dpdp_checklist.py --web --processors --children -o checklist.md
python scripts/datastore_assessment.py assets/datastore-inventory-example.json --india-only
python scripts/penalty_lookup.py all --factors
```

## Example prompts
- "I'm building a Django SaaS for Indian clinics. Design the data model and
  deletion flow for DPDP."
- "Review this signup form and cookie banner for DPDP compliance." (paste
  code)
- "Postgres or MongoDB for user data under DPDP? We use AWS."
- "We had an S3 bucket exposed for 2 days. What do we do in the next 72
  hours?"
- "Generate a DPDP gap assessment for an ed-tech app used by 12-year-olds."

## Sources and accuracy
- **Act:** The Digital Personal Data Protection Act, 2023 (No. 22 of 2023),
  Gazette of India Extraordinary, Part II Section 1, 11 August 2023. The
  reference files summarise and restructure it with section citations.
- **Rules:** `references/dpdp-rules-2025.md` is a working summary of the
  DPDP Rules, 2025 (notified 13 Nov 2025) compiled from public sources.
  **Verify against the official text at meity.gov.in.**
- Commencement dates, thresholds and notifications (restricted countries,
  SDFs, exempt startups) can change. PRs to keep this current are welcome.

## Disclaimer
This is general information and engineering guidance, **not legal advice**.
Consult qualified counsel for decisions with legal consequences.

## License
Skill content and code: MIT (see `LICENSE`). The text of Indian statutes is
not subject to copyright restrictions on reproduction (Copyright Act 1957,
s. 52(1)(q)).
