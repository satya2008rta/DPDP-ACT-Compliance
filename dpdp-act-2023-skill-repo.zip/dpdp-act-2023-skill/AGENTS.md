# Agent instructions

This repository contains a skill for India's Digital Personal Data
Protection Act, 2023 (DPDP) and building compliant web applications.

When a task involves personal data of people in India, apply the skill. Such
tasks include:
- signup/login;
- forms;
- cookies and analytics;
- databases and hosting region;
- encryption;
- account deletion;
- retention;
- logging;
- breach response;
- children's data;
- vendor integrations;
- AI features;
- privacy notices;
- compliance questions.

To apply it:
1. Read `dpdp-act-2023/SKILL.md` first.
2. Load only the `dpdp-act-2023/references/*.md` files it routes you to.
3. Cite sections of the Act (e.g., `s. 8(6)`) in explanations and code review
   findings.
